import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, Border, FontFamily, FontSize } from "../GlobalStyles";

const PembuatanAccount1 = () => {
  const navigation = useNavigation();

  return (
    <Pressable
      style={styles.pembuatanAccount1}
      onPress={() => navigation.navigate("PembuatanAccount2")}
    >
      <View style={styles.pembuatanAccount1Child} />
      <Text style={[styles.enterYourPhone, styles.text12FlexBox]}>
        Enter your phone number
      </Text>
      <Text style={styles.loginOrSign}>
        Login or sign up to place your order
      </Text>
      <View style={[styles.frameParent, styles.frameParentLayout]}>
        <View style={[styles.parent, styles.parentLayout]}>
          <Text style={[styles.text, styles.textTypo1]}>+62</Text>
          <Text style={[styles.text1, styles.textTypo1]}>8121064 1774</Text>
        </View>
        <Image
          style={[styles.frameChild, styles.parentLayout]}
          resizeMode="cover"
          source={require("../assets/frame-404.png")}
        />
      </View>
      <Image
        style={[styles.iconIndonesia, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/-icon-indonesia.png")}
      />
      <Pressable
        style={[styles.pembuatanAccount1Item, styles.frameParentLayout]}
        onPress={() => navigation.navigate("PembuatanAccount2")}
      />
      <Text style={styles.continue}>Continue</Text>
      <View style={[styles.numberKeyboard, styles.numberPosition]}>
        <Image
          style={[styles.numberKeyboardChild, styles.numberPosition]}
          resizeMode="cover"
          source={require("../assets/rectangle-3.png")}
        />
        <View style={styles.view}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle.png")}
          />
          <Text style={[styles.text2, styles.textTypo]}>0</Text>
        </View>
        <View style={[styles.view1, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle1.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>9</Text>
        </View>
        <View style={[styles.view2, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle2.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>8</Text>
        </View>
        <View style={[styles.view3, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle3.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>7</Text>
        </View>
        <View style={[styles.view4, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle4.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>6</Text>
        </View>
        <View style={[styles.view5, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle5.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>5</Text>
        </View>
        <View style={[styles.view6, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle11.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>4</Text>
        </View>
        <View style={[styles.view7, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle7.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>3</Text>
        </View>
        <View style={[styles.view8, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle8.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>2</Text>
        </View>
        <View style={[styles.view9, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle9.png")}
          />
          <Text style={[styles.text3, styles.textTypo]}>1</Text>
        </View>
        <Image
          style={[styles.fill1Icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/fill-1.png")}
        />
      </View>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
      <Text style={[styles.text12, styles.text12FlexBox]}>9:30</Text>
      <View style={styles.frame}>
        <View style={[styles.rectangle, styles.rectanglePosition]} />
        <View style={[styles.rectangle1, styles.rectanglePosition]} />
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  text12FlexBox: {
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  frameParentLayout: {
    width: 319,
    position: "absolute",
  },
  parentLayout: {
    borderRadius: Border.br_8xs,
    position: "absolute",
  },
  textTypo1: {
    top: 7,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  numberPosition: {
    left: "0%",
    right: "0%",
    position: "absolute",
    width: "100%",
  },
  textTypo: {
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_11xl,
    width: "20.24%",
    height: "79.55%",
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  viewPosition2: {
    top: 93,
    height: 47,
    width: 99,
    position: "absolute",
  },
  viewPosition1: {
    top: 37,
    height: 47,
    width: 99,
    position: "absolute",
  },
  viewPosition: {
    top: -22,
    height: 47,
    width: 99,
    position: "absolute",
  },
  rectanglePosition: {
    backgroundColor: Color.darkgray_100,
    height: 34,
    top: 0,
    position: "absolute",
  },
  pembuatanAccount1Child: {
    backgroundColor: "#c4c4c4",
    width: 375,
    height: 812,
    left: 0,
    top: 0,
    position: "absolute",
  },
  enterYourPhone: {
    top: 97,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    width: 331,
    height: 33,
    left: 27,
    textAlign: "left",
  },
  loginOrSign: {
    top: 133,
    width: 297,
    height: 23,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    left: 27,
    position: "absolute",
  },
  text: {
    left: 7,
    width: 31,
    height: 20,
    color: Color.black,
    top: 7,
  },
  text1: {
    left: 49,
    color: Color.darkgray_200,
    width: 102,
    height: 25,
  },
  parent: {
    left: 68,
    backgroundColor: Color.darkgray_300,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 251,
    height: 38,
    top: 0,
  },
  frameChild: {
    top: -5,
    left: -5,
    width: 66,
    height: 48,
  },
  frameParent: {
    top: 183,
    height: 38,
    left: 29,
  },
  iconIndonesia: {
    height: "2.46%",
    width: "7.73%",
    top: "23.65%",
    right: "82.4%",
    bottom: "73.89%",
    left: "9.87%",
    position: "absolute",
  },
  pembuatanAccount1Item: {
    top: 467,
    left: 28,
    backgroundColor: Color.steelblue,
    height: 61,
    borderRadius: Border.br_3xs,
    width: 319,
  },
  continue: {
    top: 483,
    left: 138,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.white,
    height: 31,
    width: 99,
    textAlign: "left",
    position: "absolute",
  },
  numberKeyboardChild: {
    height: "137.38%",
    top: "-17.29%",
    bottom: "-20.09%",
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  rectangleIcon: {
    height: "104.27%",
    width: "102.02%",
    top: "0%",
    right: "-1.01%",
    bottom: "-4.27%",
    left: "-1.01%",
    position: "absolute",
  },
  text2: {
    top: "11.07%",
    left: "42.88%",
  },
  view: {
    top: 153,
    height: 47,
    left: 125,
    width: 99,
    position: "absolute",
  },
  text3: {
    top: "6.82%",
    left: "39.88%",
  },
  view1: {
    left: 231,
  },
  view2: {
    left: 125,
    top: 93,
  },
  view3: {
    left: 15,
  },
  view4: {
    left: 231,
  },
  view5: {
    left: 124,
  },
  view6: {
    left: 15,
  },
  view7: {
    left: 231,
  },
  view8: {
    left: 124,
  },
  view9: {
    left: 15,
  },
  fill1Icon: {
    height: "9.59%",
    width: "7.41%",
    top: "75.36%",
    right: "16.12%",
    bottom: "15.05%",
    left: "76.47%",
    position: "absolute",
  },
  numberKeyboard: {
    height: "27.45%",
    top: "73.15%",
    bottom: "-0.6%",
  },
  topbarElementIcon: {
    marginTop: -389.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  text12: {
    top: 15,
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    width: 26,
    height: 19,
    left: 29,
  },
  rectangle: {
    width: 300,
    left: 0,
  },
  rectangle1: {
    left: 316,
    width: 34,
  },
  frame: {
    top: 387,
    left: -1,
    width: 350,
    height: 34,
    position: "absolute",
    overflow: "hidden",
    backgroundColor: Color.white,
  },
  pembuatanAccount1: {
    flex: 1,
    height: 808,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default PembuatanAccount1;
