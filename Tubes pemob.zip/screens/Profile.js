import * as React from "react";
import { Image, StyleSheet, Text, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const Profile = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.profile}>
      <Image
        style={[styles.iconlylighthome, styles.iconlylighthomeLayout]}
        resizeMode="cover"
        source={require("../assets/iconlylighthome.png")}
      />
      <Image
        style={[styles.fiRrShoppingCartIcon, styles.cartLayout]}
        resizeMode="cover"
        source={require("../assets/firrshoppingcart.png")}
      />
      <Image
        style={styles.iconlycurvedprofile}
        resizeMode="cover"
        source={require("../assets/iconlycurvedprofile.png")}
      />
      <Text style={[styles.home, styles.profileLayout]}>Home</Text>
      <Text style={[styles.cart, styles.profileLayout]}>Cart</Text>
      <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
      <Image
        style={[styles.profileChild, styles.profileLayout]}
        resizeMode="cover"
        source={require("../assets/vector-5.png")}
      />
      <Text style={[styles.profile2, styles.helloFlexBox]}>Profile</Text>
      <Image
        style={[styles.profileItem, styles.profileItemPosition]}
        resizeMode="cover"
        source={require("../assets/ellipse-45.png")}
      />
      <Text style={[styles.hello, styles.helloTypo]}>Hello,</Text>
      <Text style={[styles.orang, styles.helloFlexBox]}>orang</Text>
      <Image
        style={[styles.ellipseIcon, styles.profileItemPosition]}
        resizeMode="cover"
        source={require("../assets/ellipse.png")}
      />
      <View style={[styles.profileInner, styles.rectangleLayout]} />
      <Image
        style={[styles.iconlylightbag4, styles.iconlylightbag4Layout]}
        resizeMode="cover"
        source={require("../assets/iconlylightbag-4.png")}
      />
      <Text style={[styles.notifications, styles.logoutTypo]}>
        Notifications
      </Text>
      <Image
        style={[styles.iconlylightOutlinearrowR, styles.iconlylightPosition]}
        resizeMode="cover"
        source={require("../assets/iconlylightoutlinearrow--right-4.png")}
      />
      <Text style={[styles.management, styles.supportTypo]}>MANAGEMENT</Text>
      <Text style={[styles.support, styles.supportTypo]}>SUPPORT</Text>
      <Image
        style={styles.fiRsBellRingIcon}
        resizeMode="cover"
        source={require("../assets/firsbellring.png")}
      />
      <View style={[styles.rectangleParent, styles.rectangleLayout]}>
        <View style={styles.groupChildShadowBox} />
        <Text style={[styles.myOrder, styles.myOrderPosition]}>My Order</Text>
        <Image
          style={styles.iconlylightOutlinearrowR1}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinearrow--right-4.png")}
        />
        <Image
          style={[styles.fiRrShoppingBagIcon, styles.iconPosition]}
          resizeMode="cover"
          source={require("../assets/firrshoppingbag.png")}
        />
      </View>
      <View style={styles.rectangleView} />
      <Image
        style={styles.profileChild1}
        resizeMode="cover"
        source={require("../assets/ellipse-46.png")}
      />
      <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
        <View style={styles.groupChildShadowBox} />
        <Pressable
          style={styles.myOrderPosition}
          onPress={() => navigation.navigate("PersonalInfo")}
        >
          <Text style={styles.logoutTypo}>My Information</Text>
        </Pressable>
        <Image
          style={[styles.iconlycurvededitSquare, styles.iconlylightbag4Layout]}
          resizeMode="cover"
          source={require("../assets/iconlycurvededit-square.png")}
        />
      </View>
      <Image
        style={[styles.iconlylightOutlinearrowR2, styles.iconlylightPosition]}
        resizeMode="cover"
        source={require("../assets/iconlylightoutlinearrow--right-4.png")}
      />
      <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
        <View style={styles.groupChildShadowBox} />
        <Pressable
          style={styles.myOrderPosition}
          onPress={() => navigation.navigate("Pembayaran3")}
        >
          <Text style={styles.logoutTypo}>Payment</Text>
        </Pressable>
        <Image
          style={styles.iconlylightOutlinearrowR1}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinearrow--right-4.png")}
        />
        <Image
          style={[styles.fiRrCreditCardIcon, styles.iconPosition]}
          resizeMode="cover"
          source={require("../assets/firrcreditcard.png")}
        />
      </View>
      <View style={styles.groupView}>
        <View style={styles.groupChildShadowBox} />
        <Text style={[styles.myOrder, styles.myOrderPosition]}>About</Text>
        <Text style={[styles.logout, styles.logoutPosition]}>Logout</Text>
        <Image
          style={styles.iconlylightOutlinearrowR1}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinearrow--right-4.png")}
        />
        <Image
          style={styles.groupChild2}
          resizeMode="cover"
          source={require("../assets/ellipse-47.png")}
        />
        <Text style={[styles.text, styles.textPosition]}>?</Text>
      </View>
      <View style={styles.groupView}>
        <View style={styles.groupChildShadowBox} />
        <Pressable
          style={styles.myOrderPosition}
          onPress={() => navigation.navigate("About")}
        >
          <Text style={styles.logoutTypo}>About</Text>
        </Pressable>
        <Pressable
          style={styles.logoutPosition}
          onPress={() => navigation.navigate("TampilanAwal")}
        >
          <Text style={styles.logoutTypo}>Logout</Text>
        </Pressable>
        <Image
          style={styles.iconlylightOutlinearrowR1}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinearrow--right-4.png")}
        />
        <Image
          style={styles.groupChild2}
          resizeMode="cover"
          source={require("../assets/ellipse-47.png")}
        />
        <Text style={[styles.text, styles.textPosition]}>?</Text>
      </View>
      <Image
        style={styles.profileChild2}
        resizeMode="cover"
        source={require("../assets/ellipse-48.png")}
      />
      <Image
        style={styles.iconlyboldedit}
        resizeMode="cover"
        source={require("../assets/iconlyboldedit.png")}
      />
      <Image
        style={styles.pngTransparentPersonalSoundIcon}
        resizeMode="cover"
        source={require("../assets/pngtransparentpersonalsoundamplificationproductsvrijeuniversiteitbrusselorganizationunitedstatescommunicationlogouttexttrademarkservicethumbnail-1.png")}
      />
      <View style={styles.groupChild5Position}>
        <View style={[styles.groupChild5, styles.groupChild5Position]} />
      </View>
      <Text style={[styles.text2, styles.textPosition]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconlylighthomeLayout: {
    height: 27,
    width: 27,
  },
  cartLayout: {
    width: 23,
    left: 171,
  },
  profileLayout: {
    height: 16,
    position: "absolute",
  },
  helloFlexBox: {
    textAlign: "left",
    position: "absolute",
  },
  profileItemPosition: {
    left: 128,
    position: "absolute",
  },
  helloTypo: {
    fontSize: FontSize.size_xs,
    color: Color.black,
  },
  rectangleLayout: {
    height: 44,
    width: 319,
    left: 28,
    position: "absolute",
  },
  iconlylightbag4Layout: {
    height: 30,
    width: 30,
    position: "absolute",
  },
  logoutTypo: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  iconlylightPosition: {
    top: 483,
    height: 24,
    width: 24,
    position: "absolute",
  },
  supportTypo: {
    left: 39,
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    color: Color.darkgray_300,
    position: "absolute",
  },
  myOrderPosition: {
    left: 70,
    top: 10,
    position: "absolute",
  },
  iconPosition: {
    left: 26,
    position: "absolute",
    overflow: "hidden",
  },
  logoutPosition: {
    left: 76,
    top: 61,
    position: "absolute",
  },
  textPosition: {
    top: 15,
    textAlign: "left",
    position: "absolute",
  },
  groupChild5Position: {
    height: 34,
    width: 375,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    position: "absolute",
  },
  iconlylighthome: {
    top: 760,
    left: 30,
    position: "absolute",
  },
  fiRrShoppingCartIcon: {
    top: 763,
    height: 23,
    position: "absolute",
    overflow: "hidden",
  },
  iconlycurvedprofile: {
    top: 764,
    left: 320,
    height: 24,
    width: 24,
    position: "absolute",
  },
  home: {
    width: 31,
    textAlign: "center",
    fontSize: FontSize.size_5xs,
    top: 788,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
    left: 28,
  },
  cart: {
    textAlign: "center",
    fontSize: FontSize.size_5xs,
    top: 788,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
    width: 23,
    left: 171,
  },
  profile1: {
    left: 316,
    color: Color.steelblue,
    width: 31,
    textAlign: "center",
    fontSize: FontSize.size_5xs,
    top: 788,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
  },
  profileChild: {
    top: 737,
    left: 296,
    width: 72,
  },
  profile2: {
    top: 40,
    fontSize: FontSize.size_17xl,
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 25,
  },
  profileItem: {
    top: 111,
    width: 120,
    height: 120,
  },
  hello: {
    top: 245,
    left: 172,
    textAlign: "left",
    position: "absolute",
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsRegular,
  },
  orang: {
    top: 265,
    left: 153,
    fontSize: FontSize.size_5xl,
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  ellipseIcon: {
    top: 108,
    width: 123,
    height: 123,
    display: "none",
  },
  profileInner: {
    top: 415,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 44,
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  iconlylightbag4: {
    top: 422,
    left: 54,
    display: "none",
  },
  notifications: {
    top: 425,
    left: 98,
    position: "absolute",
  },
  iconlylightOutlinearrowR: {
    left: 310,
  },
  management: {
    top: 384,
    fontSize: FontSize.size_3xs,
  },
  support: {
    top: 589,
    fontSize: FontSize.size_3xs,
  },
  fiRsBellRingIcon: {
    top: 424,
    height: 26,
    left: 54,
    width: 27,
    position: "absolute",
    overflow: "hidden",
  },
  groupChildShadowBox: {
    left: 0,
    top: 0,
    height: 44,
    width: 319,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.2)",
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  myOrder: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  iconlylightOutlinearrowR1: {
    left: 282,
    top: 10,
    height: 24,
    width: 24,
    position: "absolute",
  },
  fiRrShoppingBagIcon: {
    width: 26,
    top: 8,
    height: 26,
  },
  rectangleParent: {
    top: 326,
  },
  rectangleView: {
    top: 427,
    left: 288,
    backgroundColor: Color.mediumseagreen_100,
    width: 39,
    height: 20,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  profileChild1: {
    top: 428,
    left: 308,
    width: 18,
    height: 18,
    position: "absolute",
  },
  iconlycurvededitSquare: {
    top: 8,
    left: 25,
  },
  rectangleGroup: {
    top: 473,
  },
  iconlylightOutlinearrowR2: {
    left: 312,
  },
  fiRrCreditCardIcon: {
    top: 9,
    height: 27,
    width: 27,
  },
  rectangleContainer: {
    top: 531,
  },
  logout: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  groupChild2: {
    top: 11,
    width: 22,
    height: 22,
    left: 29,
    position: "absolute",
  },
  text: {
    left: 38,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    width: 6,
    height: 15,
    fontSize: FontSize.size_3xs,
    color: Color.steelblue,
  },
  groupView: {
    top: 618,
    height: 85,
    width: 319,
    left: 28,
    position: "absolute",
  },
  profileChild2: {
    top: 199,
    left: 221,
    width: 25,
    height: 25,
    position: "absolute",
  },
  iconlyboldedit: {
    top: 204,
    left: 227,
    width: 14,
    height: 14,
    position: "absolute",
  },
  pngTransparentPersonalSoundIcon: {
    top: 676,
    left: 53,
    height: 29,
    width: 31,
    position: "absolute",
  },
  groupChild5: {
    backgroundColor: Color.white,
  },
  text2: {
    height: 19,
    left: 29,
    width: 26,
    fontSize: FontSize.size_xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 15,
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  profile: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default Profile;
