import * as React from "react";
import { Text, StyleSheet, Image, View } from "react-native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const WelcomeLogin = () => {
  return (
    <View style={styles.welcomeLogin}>
      <Text style={[styles.helloTeng, styles.textTypo]}>Hello, teng</Text>
      <Text style={styles.thanksForJoining}>Thanks for joining!</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
      <Text style={[styles.text, styles.textTypo]}>9:30</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  helloTeng: {
    top: 333,
    left: 62,
    fontSize: 47,
    width: 313,
    height: 70,
    color: Color.steelblue,
  },
  thanksForJoining: {
    top: 422,
    left: 85,
    fontSize: 23,
    lineHeight: 28,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "center",
    width: 212,
    height: 57,
    color: Color.steelblue,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -389.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  text: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    color: Color.black,
    width: 26,
    height: 19,
  },
  welcomeLogin: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.white,
    flex: 1,
    width: "100%",
    height: 808,
    overflow: "hidden",
  },
});

export default WelcomeLogin;
