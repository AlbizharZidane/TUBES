import * as React from "react";
import { Text, StyleSheet, Image, Pressable, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const SupportChart = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.supportChart}>
      <Text style={[styles.support, styles.textTypo]}>Support</Text>
      <Pressable style={styles.iconlytwoTonearrowLeft2} onPress={() => {}}>
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-2.png")}
        />
      </Pressable>
      <View style={styles.supportChartChild} />
      <Image
        style={styles.iconlyboldsend}
        resizeMode="cover"
        source={require("../assets/iconlyboldsend.png")}
      />
      <View style={[styles.supportChartItem, styles.supportLayout]} />
      <View style={[styles.supportChartInner, styles.supportLayout]} />
      <Text style={[styles.helloWelcomeTo, styles.helloTypo]}>{`Hello,
Welcome to support ! How can we 
help you ?`}</Text>
      <Text style={[styles.helloIHad, styles.helloTypo]}>{`Hello,
I had query regarding payment details of my last order.`}</Text>
      <Text style={[styles.pm, styles.pmTypo]}>10:40 pm</Text>
      <Text style={[styles.pm1, styles.pmTypo]}>10:42 pm</Text>
      <View style={styles.groupPosition}>
        <View style={[styles.groupChild, styles.groupPosition]} />
      </View>
      <Text style={[styles.text, styles.textTypo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  supportLayout: {
    height: 75,
    backgroundColor: Color.mediumseagreen_200,
    borderRadius: 13,
    position: "absolute",
  },
  helloTypo: {
    lineHeight: 16,
    fontSize: 13,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  pmTypo: {
    height: 13,
    width: 52,
    color: Color.darkgray_300,
    lineHeight: 12,
    fontSize: FontSize.size_2xs_7,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    width: 375,
    left: "50%",
    top: 0,
    marginLeft: -187.5,
    position: "absolute",
  },
  support: {
    top: 80,
    left: 24,
    fontSize: FontSize.size_17xl,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft2: {
    left: 16,
    top: 42,
    width: 35,
    height: 35,
    position: "absolute",
  },
  supportChartChild: {
    top: 738,
    borderRadius: Border.br_8xs,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    width: 319,
    height: 45,
    left: 28,
    position: "absolute",
    backgroundColor: Color.white,
  },
  iconlyboldsend: {
    top: 746,
    left: 301,
    width: 30,
    height: 30,
    position: "absolute",
  },
  supportChartItem: {
    top: 622,
    left: 109,
    width: 239,
  },
  supportChartInner: {
    top: 506,
    width: 261,
    left: 28,
  },
  helloWelcomeTo: {
    top: 517,
    left: 40,
    width: 243,
    height: 63,
  },
  helloIHad: {
    top: 633,
    left: 123,
    width: 216,
    height: 53,
  },
  pm: {
    top: 588,
    left: 241,
  },
  pm1: {
    top: 704,
    left: 293,
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  text: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    width: 26,
    height: 19,
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  supportChart: {
    borderRadius: Border.br_3xs,
    flex: 1,
    height: 812,
    overflow: "hidden",
    display: "none",
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default SupportChart;
