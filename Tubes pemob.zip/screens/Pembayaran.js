import * as React from "react";
import { Text, StyleSheet, Image, View, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Pembayaran = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.pembayaran}>
      <Text style={[styles.payment, styles.codTypo]}>Payment</Text>
      <Image
        style={styles.iconlytwoTonearrowLeft2}
        resizeMode="cover"
        source={require("../assets/iconlytwotonearrow--left-4.png")}
      />
      <View style={styles.rectangleParent}>
        <View style={styles.groupChild} />
        <Text style={[styles.cod, styles.codTypo]}>Cod</Text>
      </View>
      <Image
        style={styles.pembayaranChild}
        resizeMode="cover"
        source={require("../assets/ellipse-26.png")}
      />
      <View style={styles.pembayaranItem} />
      <Pressable
        style={styles.done}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Text style={styles.done1}>Done</Text>
      </Pressable>
      <Image
        style={[styles.pembayaranInner, styles.textLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-49.png")}
      />
      <Text style={[styles.totalPayment, styles.rp140000Position]}>
        TOTAL PAYMENT
      </Text>
      <Text style={[styles.rp140000, styles.rp140000Position]}>Rp140.000</Text>
      <View style={styles.groupPosition}>
        <View style={[styles.groupItem, styles.groupPosition]} />
      </View>
      <Text style={[styles.text, styles.textLayout]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  codTypo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  textLayout: {
    height: 19,
    position: "absolute",
  },
  rp140000Position: {
    top: 678,
    textAlign: "left",
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    width: 375,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    position: "absolute",
  },
  payment: {
    top: 81,
    fontSize: FontSize.size_17xl,
    left: 24,
    textAlign: "left",
    position: "absolute",
  },
  iconlytwoTonearrowLeft2: {
    top: 43,
    left: 16,
    width: 35,
    height: 35,
    position: "absolute",
  },
  groupChild: {
    left: 0,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    top: 0,
    height: 54,
    width: 320,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  cod: {
    top: 12,
    left: 18,
    width: 54,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  rectangleParent: {
    top: 155,
    height: 54,
    width: 320,
    left: 24,
    position: "absolute",
  },
  pembayaranChild: {
    top: 170,
    left: 302,
    width: 24,
    height: 24,
    position: "absolute",
  },
  pembayaranItem: {
    top: 726,
    backgroundColor: Color.steelblue,
    width: 319,
    height: 61,
    left: 27,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  done1: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.white,
    textAlign: "center",
    width: 160,
    height: 31,
    fontSize: FontSize.size_xl,
  },
  done: {
    left: 108,
    top: 741,
    position: "absolute",
  },
  pembayaranInner: {
    top: 173,
    left: 304,
    width: 19,
  },
  totalPayment: {
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsRegular,
    left: 27,
    color: Color.black,
    top: 678,
  },
  rp140000: {
    left: 245,
    color: Color.steelblue,
    fontSize: FontSize.size_xl,
    top: 678,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  groupItem: {
    backgroundColor: Color.white,
  },
  text: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    width: 26,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  pembayaran: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default Pembayaran;
