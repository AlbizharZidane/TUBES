import * as React from "react";
import { StyleSheet, View, Pressable, Image, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const HomePeripheral = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homePeripheral}>
      <Pressable
        style={styles.homePeripheralChild}
        onPress={() => navigation.navigate("Search")}
      />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={styles.search}>{`search `}</Text>
      <Image
        style={styles.maskGroupIconPosition}
        resizeMode="cover"
        source={require("../assets/mask-group.png")}
      />
      <LinearGradient
        style={[styles.homePeripheralItem, styles.maskGroupIconPosition]}
        locations={[0, 0.25, 1]}
        colors={["#000", "#000", "rgba(0, 0, 0, 0)"]}
        useAngle={true}
        angle={90}
      />
      <Text style={[styles.rp150000, styles.ps5Clr]}>Rp150.000</Text>
      <Text style={[styles.flashSale, styles.ps5Typo]}>Flash sale</Text>
      <Text style={[styles.exploreCategories, styles.textTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.exploreCategories, styles.textTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.ps5, styles.ps5Typo]}>PS 5 + GOW Ragnarok</Text>
      <Text style={[styles.only, styles.ps5Typo]}>only</Text>
      <View style={[styles.homePeripheralInner, styles.homeChildShadowBox]} />
      <View style={[styles.rectangleView, styles.homeChildShadowBox]} />
      <View style={[styles.homePeripheralChild1, styles.homeChildShadowBox]} />
      <View style={[styles.homePeripheralChild2, styles.homeChildShadowBox]} />
      <Pressable
        style={[
          styles.playstationLogowine1,
          styles.playstationLogowine1Position,
        ]}
        onPress={() => navigation.navigate("HomePlaystation")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/playstationlogowine-1.png")}
        />
      </Pressable>
      <Text style={[styles.playstation, styles.textTypo]}>Playstation</Text>
      <Text style={[styles.nintendo, styles.xboxTypo]}>Nintendo</Text>
      <Text style={[styles.peripheral, styles.xboxTypo]}>Peripheral</Text>
      <Pressable
        style={styles.showAll}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Text style={[styles.showAll1, styles.ps5Typo]}>Show all</Text>
      </Pressable>
      <Text style={[styles.vodka, styles.textTypo]}>Vodka</Text>
      <Image
        style={styles.frameIcon}
        resizeMode="cover"
        source={require("../assets/frame.png")}
      />
      <Text style={[styles.xbox, styles.xboxTypo]}>Xbox</Text>
      <View style={styles.downNavBarParent}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homeLayout]}>
          <Image
            style={[styles.homeChild, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <View style={styles.rectangleParent}>
        <View style={[styles.frameChild, styles.frameShadowBox]} />
        <Text style={[styles.rp50000, styles.rp50000Typo]}>Rp50.000</Text>
        <View style={[styles.frameItem, styles.frameShadowBox]} />
        <View style={[styles.frameInner, styles.frameShadowBox]} />
        <View style={[styles.headphoneParent, styles.textPosition]}>
          <Text style={[styles.headphone, styles.vrPs5Typo1]}>Headphone</Text>
          <Text style={[styles.rp500001, styles.rp50000Typo]}>Rp50.000</Text>
        </View>
        <View style={styles.vrPs5Parent}>
          <Text style={[styles.vrPs5, styles.vrPs5Layout]}>Vr Ps5</Text>
          <Text style={styles.rp70000}>Rp70.000</Text>
          <Image
            style={[styles.download81, styles.headphonePosition]}
            resizeMode="cover"
            source={require("../assets/download-8-1.png")}
          />
          <Text style={[styles.leftInStock, styles.leftInStockLayout]}>
            10 left in Stock
          </Text>
        </View>
        <Text style={[styles.controller, styles.vrPs5Typo1]}>Controller</Text>
      </View>
      <Text style={[styles.peripheral1, styles.textTypo]}>Peripheral</Text>
      <Image
        style={styles.playstationVrPngTransparentIcon}
        resizeMode="cover"
        source={require("../assets/2162167372-playstationvrpngtransparentpng-2.png")}
      />
      <Image
        style={[styles.cznmcy1wcml2yxrll3jhd3bpegvsx2Icon, styles.homeLayout]}
        resizeMode="cover"
        source={require("../assets/cznmcy1wcml2yxrll3jhd3bpegvsx2ltywdlcy93zwjzaxrlx2nvbnrlbnqvcgytczczlxbhas0xntgta2fuyxrlltaxlnbuzw-2.png")}
      />
      <Image
        style={[
          styles.pngTransparentNintendoSwitcIcon,
          styles.playstationLogowine1Position,
        ]}
        resizeMode="cover"
        source={require("../assets/pngtransparentnintendoswitchwiiulumologonintendoangletextnintendo-3.png")}
      />
      <Pressable
        style={[styles.pngTransparentXbox360Black, styles.vrPs5Layout]}
        onPress={() => navigation.navigate("HomeXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentxbox360blackxboxangleelectronicslogo-3.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.pngTransparentBlackJoystick, styles.leftInStockLayout]}
        onPress={() => navigation.navigate("HomePeripheral")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentblackjoystickplaystation3gamecontrollerscontrollerelectronicsvideogameblack-3.png")}
        />
      </Pressable>
      <View style={styles.homePeripheralChild3} />
      <View style={[styles.downNavBarGroup, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homeLayout]}>
          <Image
            style={[styles.homeItem, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.downNavBarContainer, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homeLayout]}>
          <Image
            style={[styles.homeInner, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <Text style={[styles.text, styles.textPosition]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  maskGroupIconPosition: {
    height: 120,
    top: 113,
    width: 317,
    left: 29,
    position: "absolute",
  },
  ps5Clr: {
    color: Color.white,
    position: "absolute",
  },
  ps5Typo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
  },
  textTypo: {
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  homeChildShadowBox: {
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  playstationLogowine1Position: {
    height: 61,
    top: 293,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  xboxTypo: {
    top: 362,
    fontSize: FontSize.size_5xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  homeLayout: {
    height: 67,
    position: "absolute",
  },
  homePosition: {
    height: 16,
    bottom: 51,
    left: "50%",
    width: 72,
    position: "absolute",
  },
  profileLayout: {
    width: 31,
    position: "absolute",
  },
  cartPosition: {
    marginLeft: -11.5,
    left: "50%",
    position: "absolute",
  },
  frameShadowBox: {
    height: 99,
    left: 0,
    width: 365,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  rp50000Typo: {
    width: 110,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  textPosition: {
    top: 15,
    position: "absolute",
  },
  vrPs5Typo1: {
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  vrPs5Layout: {
    width: 51,
    position: "absolute",
  },
  headphonePosition: {
    left: 0,
    position: "absolute",
  },
  leftInStockLayout: {
    width: 65,
    position: "absolute",
  },
  downPosition: {
    top: 809,
    height: 75,
    width: 375,
    position: "absolute",
  },
  homePeripheralChild: {
    top: 55,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 29,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 68,
    left: 44,
    width: 12,
    height: 12,
    position: "absolute",
    overflow: "hidden",
  },
  search: {
    top: 65,
    left: 67,
    textAlign: "left",
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  homePeripheralItem: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    height: 120,
  },
  rp150000: {
    top: 179,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
    color: Color.white,
    textAlign: "left",
  },
  flashSale: {
    top: 124,
    left: 43,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  exploreCategories: {
    top: 247,
    left: 28,
    fontSize: FontSize.size_base,
    color: Color.black,
    position: "absolute",
  },
  ps5: {
    top: 212,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    position: "absolute",
    left: 42,
  },
  only: {
    top: 168,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
  },
  homePeripheralInner: {
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    left: 29,
  },
  rectangleView: {
    left: 111,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homePeripheralChild1: {
    left: 193,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homePeripheralChild2: {
    left: 276,
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  icon: {
    overflow: "hidden",
  },
  playstationLogowine1: {
    left: 15,
    width: 101,
  },
  playstation: {
    top: 363,
    left: 46,
    fontSize: FontSize.size_5xs,
    position: "absolute",
  },
  nintendo: {
    left: 127,
  },
  peripheral: {
    left: 292,
  },
  showAll1: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  showAll: {
    left: 305,
    top: 256,
    position: "absolute",
  },
  vodka: {
    top: 395,
    left: 381,
    fontSize: FontSize.size_5xs,
    position: "absolute",
  },
  frameIcon: {
    top: 328,
    left: 382,
    height: 65,
    width: 23,
    position: "absolute",
    overflow: "hidden",
  },
  xbox: {
    left: 220,
  },
  downShadowBox: {
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    bottom: 0,
    marginLeft: -187.5,
    left: "50%",
    height: 75,
    width: 375,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  homeChild: {
    marginLeft: -35.87,
  },
  iconlylighthome: {
    marginLeft: -14.13,
    bottom: 17,
    width: 27,
    height: 27,
    left: "50%",
    position: "absolute",
  },
  home1: {
    marginLeft: -16.13,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    left: "50%",
    color: Color.steelblue,
  },
  home: {
    left: 8,
    top: 0,
    width: 72,
  },
  fiRrShoppingCartIcon: {
    bottom: 18,
    height: 23,
    width: 23,
    overflow: "hidden",
  },
  cart1: {
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    width: 23,
    color: Color.darkgray_300,
  },
  cart: {
    top: 25,
    left: 167,
    height: 41,
    width: 23,
    position: "absolute",
  },
  iconlycurvedprofile: {
    bottom: 16,
    width: 24,
    height: 24,
  },
  profile1: {
    marginLeft: -15.5,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    left: "50%",
    color: Color.darkgray_300,
  },
  profile: {
    top: 27,
    left: 316,
    height: 40,
  },
  downNavBarParent: {
    top: 808,
    left: -8,
    height: 75,
    width: 375,
    position: "absolute",
  },
  frameChild: {
    top: 226,
  },
  rp50000: {
    top: 284,
    left: 93,
  },
  frameItem: {
    top: 0,
  },
  frameInner: {
    top: 113,
    height: 99,
  },
  headphone: {
    width: 95,
    left: 0,
    position: "absolute",
    top: 0,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  rp500001: {
    top: 40,
    left: 1,
  },
  headphoneParent: {
    width: 111,
    height: 70,
    left: 93,
  },
  vrPs5: {
    left: 87,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_sm,
    color: Color.black,
    top: 0,
  },
  rp70000: {
    top: 37,
    left: 88,
    width: 108,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  download81: {
    top: 115,
    width: 69,
    height: 60,
  },
  leftInStock: {
    top: 59,
    color: Color.red,
    display: "none",
    left: 87,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_5xs,
  },
  vrPs5Parent: {
    top: 130,
    width: 196,
    height: 175,
    left: 6,
    position: "absolute",
  },
  controller: {
    top: 235,
    width: 80,
    left: 93,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  rectangleParent: {
    top: 444,
    height: 325,
    width: 365,
    left: 6,
    position: "absolute",
  },
  peripheral1: {
    top: 393,
    left: 8,
    fontSize: FontSize.size_base,
    color: Color.black,
    position: "absolute",
  },
  playstationVrPngTransparentIcon: {
    top: 568,
    left: 4,
    width: 83,
    height: 46,
    position: "absolute",
  },
  cznmcy1wcml2yxrll3jhd3bpegvsx2Icon: {
    top: 447,
    left: 16,
    width: 67,
  },
  pngTransparentNintendoSwitcIcon: {
    left: 115,
    width: 61,
  },
  pngTransparentXbox360Black: {
    left: 204,
    top: 298,
    height: 51,
  },
  pngTransparentBlackJoystick: {
    left: 282,
    top: 300,
    height: 44,
  },
  homePeripheralChild3: {
    marginLeft: -188,
    height: 34,
    top: 0,
    left: "50%",
    width: 375,
    position: "absolute",
    backgroundColor: Color.white,
  },
  homeItem: {
    marginLeft: -24.13,
  },
  downNavBarGroup: {
    left: -20,
  },
  homeInner: {
    marginLeft: -28.13,
  },
  downNavBarContainer: {
    left: -16,
  },
  text: {
    width: 26,
    height: 19,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_xs,
    top: 15,
    left: 29,
  },
  topbarElementIcon: {
    marginTop: -421.42,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  homePeripheral: {
    flex: 1,
    height: 877,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default HomePeripheral;
