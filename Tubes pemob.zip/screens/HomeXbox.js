import * as React from "react";
import { StyleSheet, View, Pressable, Image, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const HomeXbox = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeXbox}>
      <Pressable
        style={styles.homeXboxChild}
        onPress={() => navigation.navigate("Search")}
      />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={styles.search}>{`search `}</Text>
      <Image
        style={styles.homeXboxItemPosition}
        resizeMode="cover"
        source={require("../assets/mask-group.png")}
      />
      <LinearGradient
        style={[styles.homeXboxItem, styles.homeXboxItemPosition]}
        locations={[0, 0.25, 1]}
        colors={["#000", "#000", "rgba(0, 0, 0, 0)"]}
        useAngle={true}
        angle={90}
      />
      <Text style={[styles.rp150000, styles.ps5Clr]}>Rp150.000</Text>
      <Text style={[styles.flashSale, styles.ps5Typo]}>Flash sale</Text>
      <Text style={[styles.exploreCategories, styles.textTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.exploreCategories, styles.textTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.ps5, styles.ps5Typo]}>PS 5 + GOW Ragnarok</Text>
      <Text style={[styles.only, styles.ps5Typo]}>only</Text>
      <View style={[styles.homeXboxInner, styles.homeChildShadowBox]} />
      <View style={[styles.rectangleView, styles.homeChildShadowBox]} />
      <View style={[styles.homeXboxChild1, styles.homeChildShadowBox]} />
      <View style={[styles.homeXboxChild2, styles.homeChildShadowBox]} />
      <Pressable
        style={[
          styles.playstationLogowine1,
          styles.playstationLogowine1Position,
        ]}
        onPress={() => navigation.navigate("HomePlaystation")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/playstationlogowine-11.png")}
        />
      </Pressable>
      <Text style={[styles.playstation, styles.vodkaTypo1]}>Playstation</Text>
      <Text style={[styles.nintendo, styles.xboxTypo1]}>Nintendo</Text>
      <Text style={[styles.peripheral, styles.xboxTypo1]}>Peripheral</Text>
      <Pressable
        style={styles.showAll}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Text style={[styles.showAll1, styles.ps5Typo]}>Show all</Text>
      </Pressable>
      <Text style={[styles.vodka, styles.vodkaTypo]}>Vodka</Text>
      <Image
        style={[styles.frameIcon, styles.frameIconLayout]}
        resizeMode="cover"
        source={require("../assets/frame1.png")}
      />
      <Pressable
        style={[styles.pngTransparentNintendoSwitc, styles.download74Layout]}
        onPress={() => navigation.navigate("HomeNinetendo")}
      />
      <Text style={[styles.xbox, styles.xboxTypo1]}>Xbox</Text>
      <View style={styles.downNavBarParent}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeChild, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={styles.rectangleParent}>
        <View style={[styles.groupChild, styles.groupShadowBox]} />
        <Text style={styles.rp140000}>Rp140.000</Text>
        <View style={styles.groupItem} />
        <View style={[styles.groupInner, styles.groupShadowBox]} />
        <Image
          style={[styles.download61, styles.xbox1Position]}
          resizeMode="cover"
          source={require("../assets/download-6-1.png")}
        />
        <View style={[styles.xbox360Parent, styles.textPosition]}>
          <Text style={[styles.xbox360, styles.xboxTypo]}>Xbox 360</Text>
          <Text style={[styles.rp70000, styles.xboxLayout]}>Rp70.000</Text>
        </View>
        <View style={[styles.xboxOneParent, styles.frameIconLayout]}>
          <Text style={[styles.xbox360, styles.xboxTypo]}>Xbox one</Text>
          <Text style={[styles.rp100000, styles.rp70000Typo]}>Rp100.000</Text>
          <Text style={[styles.leftInStock, styles.leftInStockLayout]}>
            10 left in Stock
          </Text>
        </View>
        <View style={[styles.xboxSeriesXWrapper, styles.xboxLayout]}>
          <Text style={[styles.xboxSeriesX, styles.xboxLayout]}>
            Xbox Series X
          </Text>
        </View>
      </View>
      <Text style={[styles.xbox1, styles.xbox1Position]}>Xbox</Text>
      <Image
        style={styles.download21}
        resizeMode="cover"
        source={require("../assets/download-2-1.png")}
      />
      <Image
        style={[
          styles.pngTransparentNintendoSwitcIcon,
          styles.playstationLogowine1Position,
        ]}
        resizeMode="cover"
        source={require("../assets/pngtransparentnintendoswitchwiiulumologonintendoangletextnintendo-3.png")}
      />
      <Pressable
        style={styles.pngTransparentXbox360Black}
        onPress={() => navigation.navigate("HomeXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentxbox360blackxboxangleelectronicslogo-3.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.pngTransparentBlackJoystick, styles.leftInStockLayout]}
        onPress={() => navigation.navigate("HomePeripheral")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentblackjoystickplaystation3gamecontrollerscontrollerelectronicsvideogameblack-3.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.download74, styles.download74Layout]}
        onPress={() => navigation.navigate("QuickOrderXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/download-7-41.png")}
        />
      </Pressable>
      <View style={[styles.groupView, styles.groupPosition]}>
        <View style={[styles.groupChild1, styles.groupPosition]} />
      </View>
      <View style={[styles.downNavBarGroup, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeItem, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.downNavBarContainer, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeInner, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <Pressable
          style={[styles.cart, styles.homePosition1]}
          onPress={() => navigation.navigate("Pembelian")}
        >
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </Pressable>
        <Pressable
          style={[styles.profile, styles.profilePosition]}
          onPress={() => navigation.navigate("Profile")}
        >
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </Pressable>
      </View>
      <Text style={[styles.text, styles.textPosition]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  homeXboxItemPosition: {
    height: 120,
    top: 113,
    width: 317,
    left: 29,
    position: "absolute",
  },
  ps5Clr: {
    color: Color.white,
    position: "absolute",
  },
  ps5Typo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
  },
  textTypo: {
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  homeChildShadowBox: {
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  playstationLogowine1Position: {
    height: 61,
    top: 293,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  vodkaTypo1: {
    fontSize: FontSize.size_5xs,
    position: "absolute",
  },
  xboxTypo1: {
    top: 362,
    fontSize: FontSize.size_5xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  vodkaTypo: {
    top: 395,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  frameIconLayout: {
    height: 65,
    position: "absolute",
  },
  download74Layout: {
    height: 70,
    position: "absolute",
  },
  homePosition1: {
    left: "50%",
    position: "absolute",
  },
  homePosition: {
    height: 16,
    bottom: 51,
    left: "50%",
    width: 72,
    position: "absolute",
  },
  profilePosition: {
    width: 31,
    left: "50%",
    position: "absolute",
  },
  cartPosition: {
    marginLeft: -11.5,
    left: "50%",
    position: "absolute",
  },
  groupShadowBox: {
    height: 96,
    left: 0,
    width: 364,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  xbox1Position: {
    left: 8,
    position: "absolute",
  },
  textPosition: {
    top: 15,
    position: "absolute",
  },
  xboxTypo: {
    fontSize: FontSize.size_sm,
    height: 20,
    top: 0,
    left: 0,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  xboxLayout: {
    width: 108,
    position: "absolute",
  },
  rp70000Typo: {
    left: 1,
    height: 29,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  leftInStockLayout: {
    width: 65,
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    top: 0,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  downPosition: {
    bottom: 5,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  homeXboxChild: {
    top: 55,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 29,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 68,
    left: 44,
    width: 12,
    height: 12,
    position: "absolute",
    overflow: "hidden",
  },
  search: {
    top: 65,
    left: 67,
    textAlign: "left",
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  homeXboxItem: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    top: 113,
  },
  rp150000: {
    top: 179,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
    color: Color.white,
    textAlign: "left",
  },
  flashSale: {
    top: 124,
    left: 43,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  exploreCategories: {
    top: 247,
    left: 28,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  ps5: {
    top: 212,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    position: "absolute",
    left: 42,
  },
  only: {
    top: 168,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
  },
  homeXboxInner: {
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    left: 29,
  },
  rectangleView: {
    left: 111,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homeXboxChild1: {
    left: 193,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homeXboxChild2: {
    left: 276,
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  icon: {
    overflow: "hidden",
  },
  playstationLogowine1: {
    width: 101,
    left: 16,
  },
  playstation: {
    top: 363,
    left: 46,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  nintendo: {
    left: 127,
  },
  peripheral: {
    left: 292,
  },
  showAll1: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  showAll: {
    left: 305,
    top: 256,
    position: "absolute",
  },
  vodka: {
    left: 381,
    fontSize: FontSize.size_5xs,
    position: "absolute",
  },
  frameIcon: {
    top: 328,
    left: 382,
    width: 23,
    overflow: "hidden",
  },
  pngTransparentNintendoSwitc: {
    top: 292,
    left: 114,
    width: 70,
  },
  xbox: {
    left: 220,
  },
  downShadowBox: {
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    bottom: 0,
    marginLeft: -187.5,
    height: 75,
    width: 375,
    left: "50%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  homeChild: {
    marginLeft: -35.87,
  },
  iconlylighthome: {
    marginLeft: -14.13,
    bottom: 17,
    width: 27,
    height: 27,
  },
  home1: {
    marginLeft: -16.13,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.steelblue,
  },
  home: {
    marginLeft: -179.23,
    height: 67,
    bottom: 8,
    width: 72,
  },
  fiRrShoppingCartIcon: {
    bottom: 18,
    height: 23,
    width: 23,
    overflow: "hidden",
  },
  cart1: {
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    width: 23,
    color: Color.darkgray_300,
  },
  cart: {
    marginLeft: -20.5,
    bottom: 9,
    height: 41,
    width: 23,
  },
  iconlycurvedprofile: {
    bottom: 16,
    width: 24,
    height: 24,
  },
  profile1: {
    marginLeft: -15.5,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
  },
  profile: {
    marginLeft: 128.5,
    height: 40,
    bottom: 8,
  },
  downNavBarParent: {
    marginLeft: -180,
    bottom: 6,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    top: 219,
  },
  rp140000: {
    top: 275,
    height: 29,
    fontSize: FontSize.size_xl,
    width: 118,
    left: 93,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  groupItem: {
    top: 0,
    height: 96,
    left: 0,
    width: 364,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  groupInner: {
    top: 110,
  },
  download61: {
    top: 14,
    width: 66,
    height: 69,
  },
  xbox360: {
    width: 74,
    height: 20,
    position: "absolute",
  },
  rp70000: {
    top: 39,
    left: 1,
    height: 29,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  xbox360Parent: {
    width: 109,
    height: 68,
    left: 93,
  },
  rp100000: {
    top: 36,
    width: 118,
    left: 1,
    position: "absolute",
  },
  leftInStock: {
    top: 57,
    color: Color.red,
    display: "none",
    left: 0,
    width: 65,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    height: 12,
  },
  xboxOneParent: {
    top: 126,
    width: 119,
    left: 93,
  },
  xboxSeriesX: {
    height: 20,
    fontSize: FontSize.size_sm,
    top: 0,
    left: 0,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  xboxSeriesXWrapper: {
    top: 228,
    height: 20,
    left: 93,
  },
  rectangleParent: {
    top: 442,
    left: 7,
    height: 315,
    width: 364,
    position: "absolute",
  },
  xbox1: {
    width: 40,
    height: 23,
    top: 395,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_base,
  },
  download21: {
    top: 576,
    width: 77,
    height: 42,
    left: 16,
    position: "absolute",
  },
  pngTransparentNintendoSwitcIcon: {
    left: 115,
    width: 61,
  },
  pngTransparentXbox360Black: {
    left: 204,
    top: 298,
    width: 51,
    height: 51,
    position: "absolute",
  },
  pngTransparentBlackJoystick: {
    left: 282,
    top: 300,
    height: 44,
  },
  download74: {
    left: 15,
    top: 667,
    width: 67,
  },
  groupChild1: {
    marginLeft: -187.5,
    height: 34,
    backgroundColor: Color.white,
  },
  groupView: {
    marginLeft: -188,
  },
  homeItem: {
    marginLeft: -26.13,
  },
  downNavBarGroup: {
    marginLeft: -192,
  },
  homeInner: {
    marginLeft: -30.13,
  },
  downNavBarContainer: {
    marginLeft: -188,
  },
  text: {
    width: 26,
    height: 19,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_xs,
    top: 15,
    left: 29,
  },
  topbarElementIcon: {
    marginTop: -421.42,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  homeXbox: {
    flex: 1,
    height: 877,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default HomeXbox;
