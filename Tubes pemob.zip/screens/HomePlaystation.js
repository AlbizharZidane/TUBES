import * as React from "react";
import { StyleSheet, View, Pressable, Image, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const HomePlaystation = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homePlaystation}>
      <Pressable
        style={styles.homePlaystationChild}
        onPress={() => navigation.navigate("Search")}
      />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={styles.search}>{`search `}</Text>
      <Image
        style={styles.maskGroupIconPosition}
        resizeMode="cover"
        source={require("../assets/mask-group.png")}
      />
      <LinearGradient
        style={[styles.homePlaystationItem, styles.maskGroupIconPosition]}
        locations={[0, 0.25, 1]}
        colors={["#000", "#000", "rgba(0, 0, 0, 0)"]}
        useAngle={true}
        angle={90}
      />
      <Text style={[styles.rp150000, styles.ps5Clr]}>Rp150.000</Text>
      <Text style={[styles.flashSale, styles.ps5Typo]}>Flash sale</Text>
      <Text style={[styles.exploreCategories, styles.playstation1Typo]}>
        Explore Categories
      </Text>
      <Text style={[styles.exploreCategories, styles.playstation1Typo]}>
        Explore Categories
      </Text>
      <Text style={[styles.ps5, styles.ps5Typo]}>PS 5 + GOW Ragnarok</Text>
      <Text style={[styles.only, styles.ps5Typo]}>only</Text>
      <View style={[styles.homePlaystationInner, styles.homeChildShadowBox]} />
      <View style={styles.rectangleView} />
      <View style={[styles.homePlaystationChild1, styles.homeChildShadowBox]} />
      <View style={[styles.homePlaystationChild2, styles.homeChildShadowBox]} />
      <Image
        style={[styles.playstationLogowine1Icon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/playstationlogowine-11.png")}
      />
      <Text style={[styles.playstation, styles.vodkaTypo]}>Playstation</Text>
      <Text style={[styles.nintendo, styles.vodkaTypo]}>Nintendo</Text>
      <Text style={[styles.peripheral, styles.xboxTypo]}>Peripheral</Text>
      <Pressable
        style={styles.showAll}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Text style={[styles.showAll1, styles.ps5Typo]}>Show all</Text>
      </Pressable>
      <Text style={[styles.vodka, styles.vodkaTypo]}>Vodka</Text>
      <Image
        style={styles.frameIcon}
        resizeMode="cover"
        source={require("../assets/frame1.png")}
      />
      <Text style={[styles.xbox, styles.xboxTypo]}>Xbox</Text>
      <View style={styles.downNavBarParent}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeChild, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.rectangleParent, styles.playstation1Position]}>
        <View style={[styles.groupChild, styles.groupShadowBox]} />
        <View style={[styles.groupItem, styles.groupItemPosition]} />
        <View style={[styles.groupInner, styles.groupShadowBox]} />
        <View style={styles.playstation4Parent}>
          <Text style={[styles.playstation4, styles.playstation4Typo]}>
            Playstation 4
          </Text>
          <Text style={styles.rp100000}>Rp100.000</Text>
          <Image
            style={styles.download1Icon}
            resizeMode="cover"
            source={require("../assets/download-1.png")}
          />
          <Text style={[styles.leftInStock, styles.vodkaTypo]}>
            10 left in Stock
          </Text>
        </View>
      </View>
      <Text style={[styles.playstation1, styles.playstation1Position]}>
        Playstation
      </Text>
      <Image
        style={[styles.ps4slimsilver011Icon, styles.iconPosition]}
        resizeMode="cover"
        source={require("../assets/170607ps4slimsilver01-1.png")}
      />
      <Pressable
        style={styles.middle2}
        onPress={() => navigation.navigate("QuickOrderPlaystation")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/3365542middle-2.png")}
        />
      </Pressable>
      <View style={[styles.playStation5Parent, styles.playParentPosition]}>
        <Text style={[styles.playStation5, styles.playstation4Typo]}>
          Play Station 5
        </Text>
        <Text style={[styles.rp140000, styles.rp80000Typo]}>Rp140.000</Text>
      </View>
      <View style={[styles.playStation3Parent, styles.playParentPosition]}>
        <Text style={[styles.playStation5, styles.playstation4Typo]}>
          Play Station 3
        </Text>
        <Text style={[styles.rp80000, styles.rp80000Typo]}>Rp80.000</Text>
      </View>
      <Pressable
        style={styles.pngTransparentNintendoSwitc}
        onPress={() => navigation.navigate("HomeNinetendo")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/pngtransparentnintendoswitchwiiulumologonintendoangletextnintendo-1.png")}
        />
      </Pressable>
      <Pressable
        style={styles.pngTransparentXbox360Black}
        onPress={() => navigation.navigate("HomeXbox")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/pngtransparentxbox360blackxboxangleelectronicslogo-1.png")}
        />
      </Pressable>
      <Pressable
        style={styles.pngTransparentBlackJoystick}
        onPress={() => navigation.navigate("HomePeripheral")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/pngtransparentblackjoystickplaystation3gamecontrollerscontrollerelectronicsvideogameblack-3.png")}
        />
      </Pressable>
      <View style={[styles.homePlaystationChild3, styles.groupItemPosition]} />
      <View style={[styles.downNavBarGroup, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeItem, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.downNavBarContainer, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeInner, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <Pressable
          style={[styles.cart, styles.homePosition1]}
          onPress={() => navigation.navigate("Pembelian")}
        >
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </Pressable>
        <Pressable
          style={[styles.profile, styles.profilePosition]}
          onPress={() => navigation.navigate("Profile")}
        >
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </Pressable>
      </View>
      <Text style={[styles.text, styles.onlyTypo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  maskGroupIconPosition: {
    height: 120,
    top: 113,
    width: 317,
    left: 29,
    position: "absolute",
  },
  ps5Clr: {
    color: Color.white,
    position: "absolute",
  },
  ps5Typo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
  },
  playstation1Typo: {
    fontSize: FontSize.size_base,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  homeChildShadowBox: {
    height: 95,
    top: 286,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  iconPosition: {
    left: 11,
    position: "absolute",
  },
  vodkaTypo: {
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  xboxTypo: {
    top: 362,
    fontSize: FontSize.size_5xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  homePosition1: {
    left: "50%",
    position: "absolute",
  },
  homePosition: {
    height: 16,
    bottom: 51,
    left: "50%",
    width: 72,
    position: "absolute",
  },
  profilePosition: {
    width: 31,
    left: "50%",
    position: "absolute",
  },
  cartPosition: {
    marginLeft: -11.5,
    left: "50%",
    position: "absolute",
  },
  playstation1Position: {
    left: 4,
    position: "absolute",
  },
  groupShadowBox: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 0,
    width: 365,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_3xs,
  },
  groupItemPosition: {
    top: 0,
    position: "absolute",
    backgroundColor: Color.white,
  },
  playstation4Typo: {
    fontSize: FontSize.size_sm,
    top: 0,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  playParentPosition: {
    left: 133,
    position: "absolute",
  },
  rp80000Typo: {
    left: 1,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  downPosition: {
    bottom: 5,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  onlyTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  homePlaystationChild: {
    top: 55,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 29,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 68,
    left: 44,
    width: 12,
    height: 12,
    position: "absolute",
    overflow: "hidden",
  },
  search: {
    top: 65,
    left: 67,
    textAlign: "left",
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    position: "absolute",
  },
  homePlaystationItem: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
  },
  rp150000: {
    top: 179,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
    textAlign: "left",
  },
  flashSale: {
    top: 124,
    left: 43,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  exploreCategories: {
    top: 247,
    left: 28,
    color: Color.black,
    position: "absolute",
  },
  ps5: {
    top: 212,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    position: "absolute",
    left: 42,
  },
  only: {
    top: 168,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
  },
  homePlaystationInner: {
    width: 71,
    height: 95,
    top: 286,
    left: 29,
  },
  rectangleView: {
    width: 72,
    left: 111,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  homePlaystationChild1: {
    left: 193,
    width: 72,
    height: 95,
    top: 286,
  },
  homePlaystationChild2: {
    left: 276,
    width: 71,
    height: 95,
    top: 286,
  },
  playstationLogowine1Icon: {
    top: 293,
    width: 101,
    height: 61,
    overflow: "hidden",
  },
  playstation: {
    top: 363,
    fontSize: FontSize.size_5xs,
    color: Color.black,
    left: 42,
  },
  nintendo: {
    left: 129,
    top: 363,
    fontSize: FontSize.size_5xs,
    color: Color.black,
  },
  peripheral: {
    left: 292,
  },
  showAll1: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  showAll: {
    left: 305,
    top: 256,
    position: "absolute",
  },
  vodka: {
    top: 395,
    left: 381,
    color: Color.black,
  },
  frameIcon: {
    top: 328,
    left: 382,
    height: 65,
    width: 23,
    position: "absolute",
    overflow: "hidden",
  },
  xbox: {
    left: 220,
  },
  downShadowBox: {
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    bottom: 0,
    marginLeft: -187.5,
    height: 75,
    width: 375,
    left: "50%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  homeChild: {
    marginLeft: -35.87,
  },
  iconlylighthome: {
    marginLeft: -14.13,
    bottom: 17,
    width: 27,
    height: 27,
  },
  home1: {
    marginLeft: -16.13,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.steelblue,
  },
  home: {
    marginLeft: -179.23,
    height: 67,
    bottom: 8,
    width: 72,
  },
  fiRrShoppingCartIcon: {
    bottom: 18,
    height: 23,
    width: 23,
    overflow: "hidden",
  },
  cart1: {
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    width: 23,
    color: Color.darkgray_300,
  },
  cart: {
    marginLeft: -20.5,
    bottom: 9,
    height: 41,
    width: 23,
  },
  iconlycurvedprofile: {
    bottom: 16,
    width: 24,
    height: 24,
  },
  profile1: {
    marginLeft: -15.5,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
  },
  profile: {
    marginLeft: 128.5,
    height: 40,
    bottom: 8,
  },
  downNavBarParent: {
    marginLeft: -179.5,
    bottom: 6,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    top: 229,
    height: 106,
    left: 0,
    width: 365,
    position: "absolute",
    backgroundColor: Color.white,
  },
  groupItem: {
    height: 102,
    left: 0,
    width: 365,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_3xs,
  },
  groupInner: {
    top: 110,
    height: 105,
    left: 0,
    width: 365,
    position: "absolute",
    backgroundColor: Color.white,
  },
  playstation4: {
    width: 95,
    left: 110,
  },
  rp100000: {
    top: 41,
    width: 107,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    left: 111,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  download1Icon: {
    top: 117,
    width: 96,
    height: 87,
    left: 0,
    position: "absolute",
  },
  leftInStock: {
    top: 71,
    color: Color.red,
    width: 59,
    display: "none",
    left: 110,
  },
  playstation4Parent: {
    top: 121,
    left: 10,
    width: 217,
    height: 204,
    position: "absolute",
  },
  rectangleParent: {
    top: 429,
    height: 335,
    width: 365,
  },
  playstation1: {
    top: 394,
    color: Color.black,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  ps4slimsilver011Icon: {
    top: 550,
    width: 111,
    height: 83,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  middle2: {
    left: 24,
    top: 441,
    width: 82,
    height: 76,
    position: "absolute",
  },
  playStation5: {
    left: 0,
  },
  rp140000: {
    top: 35,
  },
  playStation5Parent: {
    top: 447,
    width: 104,
    height: 65,
  },
  rp80000: {
    top: 44,
  },
  playStation3Parent: {
    top: 667,
    width: 97,
    height: 74,
  },
  pngTransparentNintendoSwitc: {
    left: 119,
    top: 299,
    width: 55,
    height: 51,
    position: "absolute",
  },
  pngTransparentXbox360Black: {
    left: 203,
    top: 295,
    width: 54,
    height: 55,
    position: "absolute",
  },
  pngTransparentBlackJoystick: {
    left: 281,
    top: 305,
    width: 65,
    height: 44,
    position: "absolute",
  },
  homePlaystationChild3: {
    height: 34,
    marginLeft: -187.5,
    width: 375,
    top: 0,
    left: "50%",
  },
  homeItem: {
    marginLeft: -26.13,
  },
  downNavBarGroup: {
    marginLeft: -191.5,
  },
  homeInner: {
    marginLeft: -30.13,
  },
  downNavBarContainer: {
    marginLeft: -187.5,
  },
  text: {
    top: 15,
    width: 26,
    height: 19,
    color: Color.black,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    left: 29,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -421.42,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  homePlaystation: {
    flex: 1,
    height: 877,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default HomePlaystation;
