import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const PersonalInfo = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.personalInfo}>
      <Text style={[styles.myInformation, styles.text3Typo]}>
        My Information
      </Text>
      <View style={styles.groupParent}>
        <View style={styles.groupContainer}>
          <View style={[styles.nameWrapper, styles.nameLayout]}>
            <Text style={[styles.name, styles.nameTypo]}>Name</Text>
          </View>
          <Text style={[styles.nopal, styles.textTypo]}>Nopal</Text>
          <Text style={[styles.konteng, styles.textTypo]}>Konteng</Text>
        </View>
        <View style={[styles.emailIdWrapper, styles.emailLayout]}>
          <Text style={[styles.emailId, styles.emailLayout]}>Email Id</Text>
        </View>
        <View style={[styles.mobileNumberWrapper, styles.mobileLayout]}>
          <Text style={[styles.mobileNumber, styles.mobileLayout]}>
            Mobile number
          </Text>
        </View>
        <Text style={[styles.nopalkonteng88googlecom, styles.textTypo]}>
          Nopalkonteng88@google.com
        </Text>
        <Text style={[styles.text, styles.textTypo]}>
          <Text style={styles.text1Typo}>{`+62 `}</Text>
          <Text style={styles.text2}>81231064 1774</Text>
        </Text>
      </View>
      <Pressable
        style={styles.iconlytwoTonearrowLeft4}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-4.png")}
        />
      </Pressable>
      <View style={styles.groupChildPosition}>
        <View style={[styles.groupChild, styles.groupChildPosition]} />
      </View>
      <Text style={[styles.text3, styles.text3Typo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  text3Typo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  nameLayout: {
    height: 23,
    width: 83,
    position: "absolute",
  },
  nameTypo: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsSemibold,
    fontWeight: "600",
    textTransform: "uppercase",
    fontSize: 14,
    left: 0,
    top: 0,
    textAlign: "left",
  },
  textTypo: {
    height: 32,
    fontSize: 21,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  emailLayout: {
    width: 82,
    height: 23,
    position: "absolute",
  },
  mobileLayout: {
    width: 128,
    height: 23,
    position: "absolute",
  },
  groupChildPosition: {
    height: 34,
    width: 375,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    position: "absolute",
  },
  myInformation: {
    top: 81,
    left: 25,
    fontSize: FontSize.size_17xl,
  },
  name: {
    height: 23,
    width: 83,
    position: "absolute",
  },
  nameWrapper: {
    left: 0,
    top: 0,
  },
  nopal: {
    width: 97,
    top: 21,
    fontSize: 21,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 0,
  },
  konteng: {
    left: 69,
    width: 99,
    top: 21,
    fontSize: 21,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  groupContainer: {
    width: 168,
    height: 53,
    left: 1,
    top: 0,
    position: "absolute",
  },
  emailId: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsSemibold,
    fontWeight: "600",
    textTransform: "uppercase",
    fontSize: 14,
    left: 0,
    top: 0,
    textAlign: "left",
  },
  emailIdWrapper: {
    top: 65,
    left: 1,
  },
  mobileNumber: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsSemibold,
    fontWeight: "600",
    textTransform: "uppercase",
    fontSize: 14,
    left: 0,
    top: 0,
    textAlign: "left",
  },
  mobileNumberWrapper: {
    top: 135,
    left: 1,
  },
  nopalkonteng88googlecom: {
    top: 84,
    left: 0,
    width: 328,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text1Typo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text2: {
    fontFamily: FontFamily.poppinsRegular,
  },
  text: {
    top: 155,
    width: 282,
    left: 0,
  },
  groupParent: {
    top: 160,
    left: 27,
    height: 186,
    width: 328,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft4: {
    left: 20,
    top: 46,
    width: 35,
    height: 35,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  text3: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    width: 26,
    height: 19,
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  personalInfo: {
    borderRadius: Border.br_3xs,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default PersonalInfo;
