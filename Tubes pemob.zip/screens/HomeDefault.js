import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const HomeDefault = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeDefault}>
      <View style={styles.rectangleParent}>
        <View style={styles.frameChild} />
        <Text style={[styles.rp80000, styles.rp80000Typo]}>Rp80.000</Text>
        <View style={[styles.frameItem, styles.frameItemPosition]} />
        <View style={styles.frameInner} />
        <Text style={styles.leftInStock}>3 left in Stock</Text>
        <Pressable
          style={[styles.middle1, styles.middle1Layout]}
          onPress={() => navigation.navigate("QuickOrderPlaystation")}
        >
          <Image
            style={styles.iconLayout}
            resizeMode="cover"
            source={require("../assets/3365542middle-1.png")}
          />
        </Pressable>
        <View style={[styles.playStation5Parent, styles.frameIconLayout]}>
          <Text style={[styles.playStation5, styles.xboxSeriesXTypo]}>
            Play Station 5
          </Text>
          <Text style={[styles.rp140000, styles.rp140000Typo]}>Rp140.000</Text>
        </View>
        <View style={[styles.xboxSeriesXParent, styles.parentLayout]}>
          <Text style={[styles.xboxSeriesX, styles.xboxSeriesXTypo]}>
            Xbox Series X
          </Text>
          <Text style={[styles.rp1400001, styles.rp140000Typo]}>Rp140.000</Text>
          <Text style={styles.leftInStock1}>10 left in Stock</Text>
        </View>
        <Text style={[styles.nintendoSwitch, styles.xboxSeriesXTypo]}>
          Nintendo Switch
        </Text>
      </View>
      <Pressable
        style={styles.homeDefaultChild}
        onPress={() => navigation.navigate("Search")}
      />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={styles.search}>{`search `}</Text>
      <Image
        style={styles.maskGroupIconPosition}
        resizeMode="cover"
        source={require("../assets/mask-group.png")}
      />
      <LinearGradient
        style={[styles.homeDefaultItem, styles.maskGroupIconPosition]}
        locations={[0, 0.25, 1]}
        colors={["#000", "#000", "rgba(0, 0, 0, 0)"]}
        useAngle={true}
        angle={90}
      />
      <Text style={[styles.rp150000, styles.rp80000Typo]}>Rp150.000</Text>
      <Text style={[styles.flashSale, styles.ps5Typo]}>Flash sale</Text>
      <Text style={[styles.exploreCategories, styles.xboxSeriesXTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.exploreCategories, styles.xboxSeriesXTypo]}>
        Explore Categories
      </Text>
      <Text style={[styles.ps5, styles.ps5Typo]}>PS 5 + GOW Ragnarok</Text>
      <Text style={[styles.only, styles.ps5Typo]}>only</Text>
      <View style={[styles.homeDefaultInner, styles.homeChildShadowBox]} />
      <View style={[styles.rectangleView, styles.homeChildShadowBox]} />
      <View style={[styles.homeDefaultChild1, styles.homeChildShadowBox]} />
      <View style={[styles.homeDefaultChild2, styles.homeChildShadowBox]} />
      <Text style={[styles.bestSeller, styles.vodkaTypo]}>Best Seller</Text>
      <Pressable
        style={[styles.playstationLogowine1, styles.download31Position]}
        onPress={() => navigation.navigate("HomePlaystation")}
      >
        <Image
          style={[styles.icon1, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/playstationlogowine-11.png")}
        />
      </Pressable>
      <Text style={[styles.playstation, styles.xboxTypo]}>Playstation</Text>
      <Text style={[styles.nintendo, styles.xboxTypo]}>Nintendo</Text>
      <Text style={[styles.peripheral, styles.xboxTypo]}>Peripheral</Text>
      <Text style={[styles.showAll, styles.ps5Typo]}>Show all</Text>
      <Text style={[styles.vodka, styles.vodkaTypo]}>Vodka</Text>
      <Image
        style={[styles.frameIcon, styles.frameIconLayout]}
        resizeMode="cover"
        source={require("../assets/frame.png")}
      />
      <Pressable
        style={[styles.pngTransparentNintendoSwitc, styles.pngPosition]}
        onPress={() => navigation.navigate("HomeNinetendo")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentnintendoswitchwiiulumologonintendoangletextnintendo-11.png")}
        />
      </Pressable>
      <Text style={[styles.xbox, styles.xboxTypo]}>Xbox</Text>
      <Pressable
        style={[styles.pngTransparentXbox360Black, styles.pngPosition]}
        onPress={() => navigation.navigate("HomeXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentxbox360blackxboxangleelectronicslogo-11.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.download31, styles.download31Position]}
        onPress={() => navigation.navigate("QuickOrderNintendi")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/download-3-31.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.download31, styles.download31Position]}
        onPress={() => navigation.navigate("QuickOrderNintendi")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/download-3-31.png")}
        />
      </Pressable>
      <View style={styles.homeParent}>
        <View style={styles.home}>
          <Image
            style={[styles.homeChild, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <Pressable
        style={[styles.download73, styles.middle1Layout]}
        onPress={() => navigation.navigate("QuickOrderXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/download-7-41.png")}
        />
      </Pressable>
      <Pressable
        style={styles.pngTransparentBlackJoystick}
        onPress={() => navigation.navigate("HomePeripheral")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentblackjoystickplaystation3gamecontrollerscontrollerelectronicsvideogameblack-3.png")}
        />
      </Pressable>
      <View style={styles.homeDefaultChild3} />
      <View style={[styles.homeGroup, styles.homeShadowBox]}>
        <View style={styles.home}>
          <Image
            style={[styles.homeItem, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.homeContainer, styles.homeShadowBox]}>
        <View style={styles.home}>
          <Image
            style={[styles.homeInner, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={styles.iconlylighthome}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profileLayout]}>Home</Text>
        </View>
        <View style={styles.cart}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profileLayout]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profileLayout]}>Profile</Text>
        </View>
      </View>
      <Text style={styles.text}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  rp80000Typo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  frameItemPosition: {
    left: 0,
    top: 0,
  },
  middle1Layout: {
    height: 70,
    position: "absolute",
  },
  frameIconLayout: {
    height: 65,
    position: "absolute",
  },
  xboxSeriesXTypo: {
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  rp140000Typo: {
    width: 110,
    textAlign: "left",
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_xl,
    left: 1,
    position: "absolute",
  },
  parentLayout: {
    width: 111,
    left: 110,
  },
  maskGroupIconPosition: {
    height: 120,
    width: 317,
    left: 29,
    top: 113,
    position: "absolute",
  },
  ps5Typo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
    position: "absolute",
  },
  homeChildShadowBox: {
    height: 95,
    top: 286,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  vodkaTypo: {
    top: 395,
    color: Color.black,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  download31Position: {
    left: 13,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  xboxTypo: {
    top: 362,
    color: Color.black,
    fontSize: FontSize.size_5xs,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  pngPosition: {
    top: 298,
    position: "absolute",
  },
  homePosition: {
    height: 16,
    bottom: 51,
    left: "50%",
    width: 72,
    position: "absolute",
  },
  profileLayout: {
    width: 31,
    position: "absolute",
  },
  cartPosition: {
    marginLeft: -11.5,
    left: "50%",
    position: "absolute",
  },
  homeShadowBox: {
    bottom: 5,
    height: 75,
    width: 375,
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    left: "50%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  frameChild: {
    top: 226,
    width: 363,
    height: 99,
    left: 1,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  rp80000: {
    top: 282,
    width: 103,
    color: Color.steelblue,
    fontSize: FontSize.size_xl,
    textAlign: "left",
    left: 110,
  },
  frameItem: {
    height: 101,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 0,
    width: 364,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  frameInner: {
    top: 113,
    left: 0,
    height: 99,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    width: 364,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  leftInStock: {
    top: 182,
    left: 287,
    width: 58,
    color: Color.red,
    fontSize: FontSize.size_5xs,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  middle1: {
    left: 15,
    width: 72,
    top: 15,
  },
  playStation5: {
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 0,
    top: 0,
    width: 103,
  },
  rp140000: {
    top: 35,
  },
  playStation5Parent: {
    width: 111,
    left: 110,
    top: 15,
  },
  xboxSeriesX: {
    width: 101,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 0,
    top: 0,
  },
  rp1400001: {
    top: 38,
  },
  leftInStock1: {
    width: 61,
    display: "none",
    top: 65,
    color: Color.red,
    fontSize: FontSize.size_5xs,
    left: 0,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  xboxSeriesXParent: {
    height: 68,
    top: 124,
    position: "absolute",
  },
  nintendoSwitch: {
    top: 250,
    width: 123,
    fontSize: FontSize.size_sm,
    color: Color.black,
    left: 110,
  },
  rectangleParent: {
    top: 435,
    left: 7,
    height: 325,
    width: 364,
    position: "absolute",
  },
  homeDefaultChild: {
    top: 55,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    left: 29,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 68,
    left: 44,
    width: 12,
    height: 12,
    position: "absolute",
    overflow: "hidden",
  },
  search: {
    left: 67,
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_xs,
    top: 65,
    textAlign: "left",
    position: "absolute",
  },
  homeDefaultItem: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    height: 120,
  },
  rp150000: {
    top: 179,
    fontSize: FontSize.size_5xl,
    color: Color.white,
    left: 42,
  },
  flashSale: {
    left: 43,
    color: Color.white,
    top: 124,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_3xs,
  },
  exploreCategories: {
    top: 247,
    left: 28,
    fontSize: FontSize.size_base,
  },
  ps5: {
    top: 212,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    left: 42,
  },
  only: {
    top: 168,
    color: Color.white,
    left: 42,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_3xs,
  },
  homeDefaultInner: {
    width: 71,
    height: 95,
    top: 286,
    left: 29,
  },
  rectangleView: {
    left: 111,
    height: 95,
    top: 286,
    width: 72,
  },
  homeDefaultChild1: {
    left: 193,
    height: 95,
    top: 286,
    width: 72,
  },
  homeDefaultChild2: {
    left: 276,
    width: 71,
    height: 95,
    top: 286,
  },
  bestSeller: {
    left: 6,
    fontSize: FontSize.size_base,
  },
  icon1: {
    overflow: "hidden",
  },
  playstationLogowine1: {
    top: 288,
    height: 61,
    width: 101,
  },
  playstation: {
    left: 42,
  },
  nintendo: {
    left: 130,
  },
  peripheral: {
    left: 291,
  },
  showAll: {
    top: 256,
    left: 305,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_3xs,
  },
  vodka: {
    left: 381,
    fontSize: FontSize.size_5xs,
    top: 395,
  },
  frameIcon: {
    top: 328,
    left: 382,
    width: 23,
    overflow: "hidden",
  },
  pngTransparentNintendoSwitc: {
    left: 120,
    width: 53,
    height: 53,
  },
  xbox: {
    left: 220,
  },
  pngTransparentXbox360Black: {
    left: 199,
    width: 59,
    height: 58,
  },
  download31: {
    top: 685,
    width: 85,
    height: 47,
  },
  homeChild: {
    marginLeft: -35.87,
  },
  iconlylighthome: {
    marginLeft: -14.13,
    bottom: 17,
    width: 27,
    height: 27,
    left: "50%",
    position: "absolute",
  },
  home1: {
    marginLeft: -16.13,
    textAlign: "center",
    bottom: 0,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_5xs,
    left: "50%",
    color: Color.steelblue,
  },
  home: {
    left: 8,
    height: 67,
    width: 72,
    top: 0,
    position: "absolute",
  },
  fiRrShoppingCartIcon: {
    bottom: 18,
    height: 23,
    width: 23,
    overflow: "hidden",
  },
  cart1: {
    textAlign: "center",
    bottom: 0,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_5xs,
    width: 23,
    color: Color.darkgray_300,
  },
  cart: {
    top: 25,
    left: 167,
    height: 41,
    width: 23,
    position: "absolute",
  },
  iconlycurvedprofile: {
    bottom: 16,
    width: 24,
    height: 24,
  },
  profile1: {
    marginLeft: -15.5,
    textAlign: "center",
    bottom: 0,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_5xs,
    left: "50%",
    color: Color.darkgray_300,
  },
  profile: {
    top: 27,
    left: 316,
    height: 40,
  },
  homeParent: {
    marginLeft: -180,
    bottom: 6,
    height: 75,
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    width: 375,
    left: "50%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  download73: {
    left: 9,
    top: 559,
    width: 67,
  },
  pngTransparentBlackJoystick: {
    left: 281,
    top: 305,
    width: 65,
    height: 44,
    position: "absolute",
  },
  homeDefaultChild3: {
    height: 34,
    marginLeft: -188,
    width: 375,
    left: "50%",
    top: 0,
    position: "absolute",
    backgroundColor: Color.white,
  },
  homeItem: {
    marginLeft: -26.13,
  },
  homeGroup: {
    marginLeft: -192,
  },
  homeInner: {
    marginLeft: -30.13,
  },
  homeContainer: {
    marginLeft: -188,
  },
  text: {
    width: 26,
    height: 19,
    fontSize: FontSize.size_xs,
    left: 29,
    color: Color.black,
    top: 15,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -421.42,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  homeDefault: {
    flex: 1,
    height: 877,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default HomeDefault;
