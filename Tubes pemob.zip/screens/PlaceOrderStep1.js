import * as React from "react";
import { StyleSheet, View, Text, Pressable, Image } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const PlaceOrderStep1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.placeOrderStep1}>
      <View style={styles.placeOrderStep1Child} />
      <Text style={[styles.subtotal, styles.backTypo]}>Subtotal</Text>
      <Text style={[styles.back, styles.backTypo]}>Back</Text>
      <Text style={[styles.taxFee, styles.backTypo]}>{`Tax & Fee`}</Text>
      <Text style={[styles.delivery, styles.backTypo]}>Delivery</Text>
      <Text style={[styles.promoCode, styles.promoCodeTypo]}>Promo Code</Text>
      <Text style={[styles.free, styles.freeTypo]}>Free</Text>
      <Text style={[styles.firsttime, styles.promoCodeTypo]}>FIRSTTIME</Text>
      <Pressable
        style={styles.placeOrderStep1Item}
        onPress={() => navigation.navigate("TampilanAwal")}
      />
      <Text style={styles.continue}>Continue</Text>
      <Image
        style={styles.placeOrderStep1Inner}
        resizeMode="cover"
        source={require("../assets/vector-6.png")}
      />
      <Image
        style={styles.dollarCurrencySymbol1Icon}
        resizeMode="cover"
        source={require("../assets/dollarcurrencysymbol-1.png")}
      />
      <Image
        style={styles.dollarCurrencySymbol2Icon}
        resizeMode="cover"
        source={require("../assets/dollarcurrencysymbol-2.png")}
      />
      <Text style={[styles.text, styles.backTypo]}>2.98</Text>
      <Text style={[styles.text1, styles.freeTypo]}>0.25</Text>
      <Text style={[styles.subtotal, styles.backTypo]}>Subtotal</Text>
      <Text style={[styles.back, styles.backTypo]}>Back</Text>
      <Text style={[styles.taxFee, styles.backTypo]}>{`Tax & Fee`}</Text>
      <Text style={[styles.delivery, styles.backTypo]}>Delivery</Text>
      <Text style={[styles.promoCode, styles.promoCodeTypo]}>Promo Code</Text>
      <Text style={[styles.free, styles.freeTypo]}>Free</Text>
      <Text style={[styles.firsttime, styles.promoCodeTypo]}>FIRSTTIME</Text>
      <Image
        style={styles.dollarCurrencySymbol1Icon}
        resizeMode="cover"
        source={require("../assets/dollarcurrencysymbol-1.png")}
      />
      <Image
        style={styles.dollarCurrencySymbol2Icon}
        resizeMode="cover"
        source={require("../assets/dollarcurrencysymbol-2.png")}
      />
      <Text style={[styles.text, styles.backTypo]}>2.98</Text>
      <Text style={[styles.text1, styles.freeTypo]}>0.25</Text>
      <Image
        style={styles.iconlyboldlocation}
        resizeMode="cover"
        source={require("../assets/iconlyboldlocation1.png")}
      />
      <Text style={styles.deliverTo}>DELIVER TO</Text>
      <Text style={styles.home154}>Home - 15/4 Roawda...</Text>
      <Image
        style={[styles.groupIcon, styles.groupIconLayout]}
        resizeMode="cover"
        source={require("../assets/group-433.png")}
      />
      <Image
        style={[styles.placeOrderStep1Child1, styles.groupIconLayout]}
        resizeMode="cover"
        source={require("../assets/group-433.png")}
      />
      <Image
        style={styles.mapsicleMapIcon}
        resizeMode="cover"
        source={require("../assets/mapsicle-map.png")}
      />
      <View style={styles.groupPosition}>
        <View style={[styles.groupChild, styles.groupPosition]} />
      </View>
      <Text style={styles.text4}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  backTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  promoCodeTypo: {
    top: 688,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  freeTypo: {
    left: 316,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  groupIconLayout: {
    height: 26,
    width: 26,
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    width: 375,
    position: "absolute",
  },
  placeOrderStep1Child: {
    top: 546,
    shadowColor: "rgba(85, 85, 85, 0.25)",
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowRadius: 11,
    elevation: 11,
    shadowOpacity: 1,
    height: 266,
    width: 375,
    left: 0,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  subtotal: {
    top: 591,
    color: Color.black,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 32,
  },
  back: {
    top: 561,
    color: Color.mediumseagreen_100,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 32,
  },
  taxFee: {
    top: 622,
    color: Color.black,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 32,
  },
  delivery: {
    top: 655,
    color: Color.black,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 32,
  },
  promoCode: {
    color: Color.black,
    left: 32,
    top: 688,
  },
  free: {
    top: 655,
  },
  firsttime: {
    left: 279,
    color: Color.mediumseagreen_100,
  },
  placeOrderStep1Item: {
    top: 726,
    left: 27,
    backgroundColor: Color.mediumseagreen_100,
    width: 319,
    height: 61,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  continue: {
    top: 741,
    left: 107,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.white,
    textAlign: "center",
    width: 160,
    height: 31,
    position: "absolute",
  },
  placeOrderStep1Inner: {
    top: 191,
    left: 57,
    width: 231,
    height: 331,
    position: "absolute",
  },
  dollarCurrencySymbol1Icon: {
    top: 589,
    left: 257,
    width: 22,
    height: 22,
    position: "absolute",
    overflow: "hidden",
  },
  dollarCurrencySymbol2Icon: {
    top: 632,
    left: 301,
    width: 11,
    height: 11,
    position: "absolute",
    overflow: "hidden",
  },
  text: {
    top: 582,
    left: 285,
    fontSize: FontSize.size_11xl,
    lineHeight: 36,
    color: Color.black,
  },
  text1: {
    top: 630,
    lineHeight: 17,
  },
  iconlyboldlocation: {
    top: 46,
    left: 25,
    width: 24,
    height: 24,
    position: "absolute",
  },
  deliverTo: {
    top: 45,
    fontSize: FontSize.size_5xs,
    letterSpacing: 0.8,
    fontFamily: FontFamily.poppinsRegular,
    left: 51,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  home154: {
    top: 55,
    fontSize: FontSize.size_xs,
    left: 51,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  groupIcon: {
    top: 186,
    left: 67,
  },
  placeOrderStep1Child1: {
    top: 510,
    left: 210,
  },
  mapsicleMapIcon: {
    height: 1554,
    top: 0,
    width: 375,
    left: 0,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  text4: {
    top: 15,
    left: 29,
    height: 19,
    width: 26,
    fontSize: FontSize.size_xs,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  placeOrderStep1: {
    flex: 1,
    width: "100%",
    height: 812,
    overflow: "hidden",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default PlaceOrderStep1;
