import * as React from "react";
import { Text, StyleSheet, Image, Pressable, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const Pembelian = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.pembelian}>
      <Text style={[styles.cart, styles.cartTypo]}>Cart</Text>
      <Pressable
        style={[styles.iconlytwoTonearrowLeft2, styles.middle3Position]}
        onPress={() => navigation.navigate("ProductPlaystation")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-4.png")}
        />
      </Pressable>
      <View style={styles.pembelianChild} />
      <Pressable
        style={styles.iconlylighthome}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlylighthome.png")}
        />
      </Pressable>
      <Image
        style={styles.fiRrShoppingCartIcon}
        resizeMode="cover"
        source={require("../assets/firrshoppingcart1.png")}
      />
      <Text style={[styles.home, styles.homeLayout]}>Home</Text>
      <Text style={styles.cart1}>Cart</Text>
      <Pressable
        style={styles.iconlycurvedprofileParent}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={[styles.iconlycurvedprofile, styles.playStation5Position]}
          resizeMode="cover"
          source={require("../assets/iconlycurvedprofile1.png")}
        />
        <Text style={[styles.profile, styles.homeLayout]}>Profile</Text>
      </Pressable>
      <Image
        style={[styles.pembelianItem, styles.homeLayout]}
        resizeMode="cover"
        source={require("../assets/vector-5.png")}
      />
      <View style={styles.pembelianInner} />
      <Text style={styles.text}>1</Text>
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <View style={[styles.pembelianChild1, styles.rectangleViewLayout]} />
      <Image
        style={[styles.fiBrPlusIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/fibrplus.png")}
      />
      <Image
        style={[styles.fiBrMinusIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/fibrminus.png")}
      />
      <View style={styles.playStation5Parent}>
        <Text style={[styles.playStation5, styles.playStation5Position]}>
          Play Station 5
        </Text>
        <Text style={[styles.rp140000, styles.rp140000Typo]}>Rp140.000</Text>
        <Text style={[styles.rp1400001, styles.rp140000Typo]}>Rp140.000</Text>
      </View>
      <Pressable
        style={styles.rectanglePressable}
        onPress={() => navigation.navigate("PlaceOrderStep1")}
      />
      <Pressable
        style={styles.placeOrder}
        onPress={() => navigation.navigate("Pembayaran")}
      >
        <Text style={[styles.placeOrder1, styles.rp140000Typo]}>
          Place Order
        </Text>
      </Pressable>
      <Text style={[styles.total, styles.totalPosition]}>{`TOTAL `}</Text>
      <Pressable
        style={[styles.middle3, styles.middle3Position]}
        onPress={() => navigation.navigate("QuickOrderPlaystation")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/3365542middle-6.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.middle3, styles.middle3Position]}
        onPress={() => navigation.navigate("QuickOrderPlaystation")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/3365542middle-4.png")}
        />
      </Pressable>
      <View style={[styles.groupView, styles.groupPosition]}>
        <View style={[styles.groupChild, styles.groupPosition]} />
      </View>
      <Text style={[styles.text1, styles.totalPosition]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  cartTypo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  middle3Position: {
    left: 16,
    position: "absolute",
  },
  homeLayout: {
    height: 16,
    position: "absolute",
  },
  playStation5Position: {
    top: 0,
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 18,
    width: 17,
    borderWidth: 0.5,
    borderColor: "#2287b9",
    borderStyle: "solid",
    borderRadius: Border.br_10xs,
    top: 213,
    position: "absolute",
  },
  iconLayout: {
    height: 9,
    width: 9,
    top: 218,
    position: "absolute",
    overflow: "hidden",
  },
  rp140000Typo: {
    fontSize: FontSize.size_xl,
    textAlign: "left",
  },
  totalPosition: {
    left: 29,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    left: "50%",
    top: 0,
    width: 375,
    position: "absolute",
  },
  cart: {
    top: 81,
    left: 25,
    fontSize: FontSize.size_17xl,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft2: {
    top: 43,
    width: 35,
    height: 35,
  },
  pembelianChild: {
    shadowColor: "rgba(85, 85, 85, 0.2)",
    shadowRadius: 3,
    elevation: 3,
    height: 75,
    width: 375,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 0,
    top: 737,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  iconlylighthome: {
    left: 30,
    top: 760,
    width: 27,
    height: 27,
    position: "absolute",
  },
  fiRrShoppingCartIcon: {
    top: 763,
    height: 23,
    width: 23,
    left: 174,
    position: "absolute",
    overflow: "hidden",
  },
  home: {
    top: 788,
    left: 28,
    width: 31,
    textAlign: "center",
    color: Color.darkgray_300,
    fontSize: FontSize.size_5xs,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
  },
  cart1: {
    top: 789,
    color: Color.steelblue,
    height: 16,
    textAlign: "center",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_5xs,
    width: 23,
    left: 174,
    position: "absolute",
  },
  iconlycurvedprofile: {
    left: 4,
    width: 24,
    height: 24,
  },
  profile: {
    top: 24,
    width: 31,
    textAlign: "center",
    color: Color.darkgray_300,
    fontSize: FontSize.size_5xs,
    height: 16,
    fontFamily: FontFamily.poppinsRegular,
    left: 0,
  },
  iconlycurvedprofileParent: {
    top: 764,
    left: 316,
    height: 40,
    width: 31,
    position: "absolute",
  },
  pembelianItem: {
    left: 150,
    width: 72,
    height: 16,
    top: 737,
  },
  pembelianInner: {
    top: 153,
    left: 5,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    width: 366,
    height: 99,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  text: {
    left: 143,
    fontSize: FontSize.size_base,
    lineHeight: 19,
    top: 213,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  rectangleView: {
    left: 110,
  },
  pembelianChild1: {
    left: 165,
  },
  fiBrPlusIcon: {
    left: 169,
  },
  fiBrMinusIcon: {
    left: 114,
  },
  playStation5: {
    fontSize: FontSize.size_sm,
    left: 0,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  rp140000: {
    top: 40,
    left: 155,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  rp1400001: {
    top: 410,
    left: 155,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  playStation5Parent: {
    top: 168,
    width: 258,
    height: 440,
    left: 110,
    position: "absolute",
  },
  rectanglePressable: {
    top: 652,
    left: 27,
    backgroundColor: Color.steelblue,
    width: 319,
    height: 61,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  placeOrder1: {
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.white,
    width: 121,
    height: 31,
  },
  placeOrder: {
    left: 126,
    top: 668,
    position: "absolute",
  },
  total: {
    top: 578,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsRegular,
    left: 29,
  },
  middle3: {
    top: 160,
    width: 80,
    height: 85,
  },
  groupChild: {
    marginLeft: -187.5,
    backgroundColor: Color.white,
    height: 34,
    left: "50%",
  },
  groupView: {
    marginLeft: -171.5,
  },
  text1: {
    top: 15,
    fontSize: FontSize.size_xs,
    width: 26,
    height: 19,
    left: 29,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  pembelian: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default Pembelian;
