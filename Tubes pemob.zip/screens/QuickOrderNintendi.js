import * as React from "react";
import { StyleSheet, View, Text, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const QuickOrderNintendi = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.quickOrderNintendi}>
      <View style={styles.frame91} />
      <View style={styles.quickOrderNintendiChild} />
      <View style={styles.dollarCurrencySymbol1} />
      <Text style={[styles.nintendoSwitch, styles.rp80000FlexBox]}>
        Nintendo Switch
      </Text>
      <Text style={[styles.nintendoSwitch, styles.rp80000FlexBox]}>
        Nintendo Switch
      </Text>
      <Text style={[styles.nintendoSwitch, styles.rp80000FlexBox]}>
        Nintendo Switch
      </Text>
      <Text style={[styles.qty, styles.qtyClr]}>Qty</Text>
      <Text style={[styles.price, styles.qtyClr]}>Price</Text>
      <Text style={styles.text}>1</Text>
      <Text style={[styles.rp80000, styles.qtyTypo]}>Rp80.000</Text>
      <View style={[styles.quickOrderNintendiItem, styles.quickLayout]} />
      <View style={[styles.quickOrderNintendiInner, styles.quickLayout]} />
      <Image
        style={[styles.fiBrPlusIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/fibrplus.png")}
      />
      <Image
        style={[styles.fiBrMinusIcon, styles.iconLayout]}
        resizeMode="cover"
        source={require("../assets/fibrminus.png")}
      />
      <View style={[styles.rectangleView, styles.rectangleViewShadowBox]} />
      <View
        style={[styles.quickOrderNintendiChild1, styles.rectangleViewShadowBox]}
      />
      <Text style={[styles.cod, styles.qtyClr]}>COD</Text>
      <View style={[styles.rectangleParent, styles.frameLayout]}>
        <View style={[styles.frameChild, styles.frameLayout]} />
        <View style={[styles.frameItem, styles.frameLayout]} />
        <Pressable
          style={styles.swipeToOrderContainer}
          onPress={() => navigation.navigate("ProductNintendo")}
        >
          <Text style={[styles.swipeToOrder, styles.qtyClr]}>
            Swipe to Order
          </Text>
        </Pressable>
        <Image
          style={styles.iconlylightOutlinearrowR}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinearrow--right-2.png")}
        />
      </View>
      <View style={styles.pngitem7587831} />
      <View style={styles.brewLogo1}>
        <Image
          style={styles.kisspngVideoGameGameControIcon}
          resizeMode="cover"
          source={require("../assets/kisspngvideogamegamecontrollerjoystickonlinegamevectorgamepad5a7166f1d5b6b1-1.png")}
        />
      </View>
      <View style={styles.brewLogo1}>
        <Image
          style={styles.kisspngVideoGameGameControIcon}
          resizeMode="cover"
          source={require("../assets/kisspngvideogamegamecontrollerjoystickonlinegamevectorgamepad5a7166f1d5b6b1-1.png")}
        />
      </View>
      <Pressable
        style={[styles.iconlytwoTonearrowLeft5, styles.frameChildPosition]}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-5.png")}
        />
      </Pressable>
      <Pressable
        style={styles.download33}
        onPress={() => navigation.navigate("QuickOrderNintendi")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/download-3-3.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  rp80000FlexBox: {
    textAlign: "left",
    color: Color.black,
  },
  qtyClr: {
    color: Color.steelblue,
    textAlign: "left",
  },
  qtyTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  quickLayout: {
    height: 18,
    width: 17,
    borderWidth: 0.5,
    borderColor: "#46de99",
    borderStyle: "solid",
    borderRadius: Border.br_10xs,
    top: 631,
    position: "absolute",
  },
  iconLayout: {
    height: 9,
    width: 9,
    top: 636,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleViewShadowBox: {
    height: 32,
    elevation: 4,
    shadowRadius: 4,
    borderRadius: Border.br_8xs,
    top: 674,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
  },
  frameLayout: {
    height: 61,
    position: "absolute",
  },
  frameChildPosition: {
    top: 0,
    left: 0,
  },
  frame91: {
    height: 812,
    width: 375,
    backgroundColor: Color.steelblue,
    left: 0,
    top: 0,
    position: "absolute",
  },
  quickOrderNintendiChild: {
    top: 467,
    left: 2,
    shadowColor: "rgba(85, 85, 85, 0.25)",
    shadowRadius: 11,
    elevation: 11,
    height: 345,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 375,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  dollarCurrencySymbol1: {
    top: 630,
    left: 246,
    width: 19,
    height: 19,
    position: "absolute",
    overflow: "hidden",
  },
  nintendoSwitch: {
    top: 509,
    left: 128,
    fontSize: FontSize.size_4xl,
    lineHeight: 28,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    position: "absolute",
  },
  qty: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    lineHeight: 19,
    fontSize: FontSize.size_base,
    color: Color.steelblue,
    left: 129,
    top: 599,
  },
  price: {
    left: 250,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    lineHeight: 19,
    fontSize: FontSize.size_base,
    color: Color.steelblue,
    top: 599,
  },
  text: {
    left: 162,
    top: 631,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    lineHeight: 19,
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  rp80000: {
    top: 626,
    left: 240,
    fontSize: FontSize.size_5xl,
    lineHeight: 29,
    textAlign: "left",
    color: Color.black,
  },
  quickOrderNintendiItem: {
    left: 129,
  },
  quickOrderNintendiInner: {
    left: 184,
  },
  fiBrPlusIcon: {
    left: 188,
  },
  fiBrMinusIcon: {
    left: 133,
  },
  rectangleView: {
    left: 130,
    backgroundColor: Color.whitesmoke_100,
    shadowColor: "#46de99",
    width: 72,
  },
  quickOrderNintendiChild1: {
    left: 217,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    width: 103,
    backgroundColor: Color.white,
  },
  cod: {
    top: 680,
    left: 147,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
    lineHeight: 19,
    fontSize: FontSize.size_base,
    color: Color.steelblue,
  },
  frameChild: {
    backgroundColor: Color.whitesmoke_200,
    width: 319,
    height: 61,
    left: 0,
    top: 0,
    borderRadius: Border.br_3xs,
  },
  frameItem: {
    left: 1,
    width: 68,
    height: 61,
    backgroundColor: Color.steelblue,
    top: 0,
    borderRadius: Border.br_3xs,
  },
  swipeToOrder: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    width: 155,
    height: 31,
  },
  swipeToOrderContainer: {
    left: 115,
    top: 15,
    position: "absolute",
  },
  iconlylightOutlinearrowR: {
    top: 8,
    left: 12,
    width: 45,
    height: 45,
    position: "absolute",
  },
  rectangleParent: {
    top: 729,
    left: 28,
    width: 319,
    height: 61,
  },
  pngitem7587831: {
    top: 484,
    left: 42,
    width: 41,
    height: 106,
    position: "absolute",
  },
  kisspngVideoGameGameControIcon: {
    height: "66.47%",
    width: "75.06%",
    top: "0%",
    right: "12.47%",
    bottom: "33.53%",
    left: "12.47%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  brewLogo1: {
    top: 98,
    left: -10,
    width: 385,
    height: 346,
    position: "absolute",
    overflow: "hidden",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft5: {
    width: 347,
    height: 35,
    left: 0,
    position: "absolute",
  },
  download33: {
    top: 523,
    width: 138,
    height: 70,
    left: 0,
    position: "absolute",
  },
  quickOrderNintendi: {
    flex: 1,
    height: 807,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default QuickOrderNintendi;
