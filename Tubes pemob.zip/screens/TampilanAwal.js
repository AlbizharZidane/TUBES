import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const TampilanAwal = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.tampilanAwal}>
      <View style={styles.brewLogo1}>
        <Image
          style={[styles.kisspngVideoGameGameControIcon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/kisspngvideogamegamecontrollerjoystickonlinegamevectorgamepad5a7166f1d5b6b1-1.png")}
        />
      </View>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
      <Text style={styles.text}>9:30</Text>
      <View style={styles.form}>
        <View style={[styles.username, styles.usernameLayout]}>
          <View style={[styles.rectangle, styles.rectangleLayout]} />
          <Text style={[styles.emailid, styles.emailidTypo]}>EMAIL.id</Text>
          <Image
            style={styles.userIcon}
            resizeMode="cover"
            source={require("../assets/user.png")}
          />
        </View>
        <View style={[styles.password, styles.usernameLayout]}>
          <View style={[styles.rectangle, styles.rectangleLayout]} />
          <Text style={[styles.password1, styles.emailidTypo]}>password</Text>
          <Image
            style={[styles.lockIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/lock.png")}
          />
        </View>
        <Pressable
          style={[styles.loginBtn, styles.usernameLayout]}
          onPress={() => navigation.navigate("PembuatanAccount1")}
        >
          <View style={[styles.rectangle2, styles.rectangleLayout]} />
          <Text style={[styles.login, styles.loginTypo]}>login</Text>
        </Pressable>
        <Pressable
          style={styles.register}
          onPress={() => navigation.navigate("PembuatanAccount1")}
        >
          <Text style={[styles.register1, styles.loginTypo]}>Register</Text>
        </Pressable>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  usernameLayout: {
    height: 45,
    left: 0,
    width: 300,
    position: "absolute",
  },
  rectangleLayout: {
    borderRadius: Border.br_9xs,
    height: 45,
    left: 0,
    top: 0,
    width: 300,
    position: "absolute",
  },
  emailidTypo: {
    textAlign: "center",
    fontFamily: FontFamily.montserratLight,
    fontWeight: "300",
    fontSize: FontSize.size_sm,
    color: Color.white,
    textTransform: "uppercase",
    lineHeight: 20,
    top: 13,
    position: "absolute",
  },
  loginTypo: {
    fontSize: FontSize.size_base,
    textAlign: "center",
  },
  kisspngVideoGameGameControIcon: {
    height: "66.47%",
    width: "75.06%",
    top: "0%",
    right: "12.47%",
    bottom: "33.53%",
    left: "12.47%",
  },
  brewLogo1: {
    top: 233,
    left: -25,
    width: 385,
    height: 346,
    position: "absolute",
    overflow: "hidden",
  },
  topbarElementIcon: {
    marginTop: -384.42,
    top: "50%",
    right: 24,
    width: 60,
    height: 10,
    position: "absolute",
  },
  text: {
    top: 20,
    left: 23,
    fontSize: FontSize.size_xs,
    fontFamily: FontFamily.poppinsMedium,
    color: Color.black,
    textAlign: "left",
    width: 26,
    height: 19,
    fontWeight: "500",
    position: "absolute",
  },
  rectangle: {
    borderStyle: "solid",
    borderColor: "#fff",
    borderWidth: 1,
  },
  emailid: {
    left: 41,
  },
  userIcon: {
    left: 12,
    width: 20,
    height: 20,
    top: 13,
    position: "absolute",
    overflow: "hidden",
  },
  username: {
    top: 0,
    height: 45,
    left: 0,
  },
  password1: {
    left: 51,
  },
  lockIcon: {
    height: "44.17%",
    width: "6.19%",
    top: "20.84%",
    right: "91.04%",
    bottom: "34.99%",
    left: "2.78%",
  },
  password: {
    top: 65,
  },
  rectangle2: {
    backgroundColor: Color.white,
    shadowColor: "rgba(0, 0, 0, 0.3)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
  },
  login: {
    left: 123,
    fontWeight: "600",
    fontFamily: FontFamily.montserratSemibold,
    color: Color.steelblue,
    fontSize: FontSize.size_base,
    textTransform: "uppercase",
    lineHeight: 20,
    top: 13,
    position: "absolute",
  },
  loginBtn: {
    top: 153,
  },
  register1: {
    fontFamily: FontFamily.montserratMedium,
    color: Color.white,
    fontSize: FontSize.size_base,
    fontWeight: "500",
  },
  register: {
    left: 116,
    top: 215,
    position: "absolute",
  },
  form: {
    top: 510,
    left: 39,
    height: 235,
    width: 300,
    position: "absolute",
  },
  tampilanAwal: {
    borderRadius: Border.br_3xs,
    backgroundColor: Color.steelblue,
    flex: 1,
    width: "100%",
    height: 807,
    overflow: "hidden",
  },
});

export default TampilanAwal;
