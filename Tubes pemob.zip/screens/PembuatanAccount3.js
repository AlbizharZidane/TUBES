import * as React from "react";
import { StyleSheet, View, Image, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const PembuatanAccount3 = () => {
  const navigation = useNavigation();

  return (
    <Pressable style={styles.pembuatanAccount3} onPress={() => {}}>
      <View style={styles.pembuatanAccount3Child} />
      <View style={[styles.numberKeyboard, styles.numberPosition]}>
        <Image
          style={[styles.numberKeyboardChild, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/rectangle-3.png")}
        />
        <View style={styles.view}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle.png")}
          />
          <Text style={[styles.text, styles.textClr]}>0</Text>
        </View>
        <View style={[styles.view1, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle1.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>9</Text>
        </View>
        <View style={[styles.view2, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle2.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>8</Text>
        </View>
        <View style={[styles.view3, styles.viewPosition2]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle3.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>7</Text>
        </View>
        <View style={[styles.view4, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle4.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>6</Text>
        </View>
        <View style={[styles.view5, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle5.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>5</Text>
        </View>
        <View style={[styles.view6, styles.viewPosition1]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle6.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>4</Text>
        </View>
        <View style={[styles.view7, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle7.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>3</Text>
        </View>
        <View style={[styles.view8, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle8.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>2</Text>
        </View>
        <View style={[styles.view9, styles.viewPosition]}>
          <Image
            style={[styles.rectangleIcon, styles.iconLayout]}
            resizeMode="cover"
            source={require("../assets/rectangle9.png")}
          />
          <Text style={[styles.text1, styles.textClr]}>1</Text>
        </View>
        <Image
          style={[styles.fill1Icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/fill-1.png")}
        />
      </View>
      <View style={styles.pembuatanAccount3Item} />
      <Pressable
        style={styles.continue}
        onPress={() => navigation.navigate("WelcomeLogin")}
      >
        <Text style={styles.continue1}>Continue</Text>
      </Pressable>
      <Text style={styles.welcome}>Welcome !!!</Text>
      <Text style={[styles.pleaseProvideUs, styles.textClr]}>
        Please provide us with few more details
      </Text>
      <View style={[styles.frameParent, styles.frameLayout]}>
        <View style={styles.passwordWrapper}>
          <Text style={[styles.password, styles.passwordTypo]}>Password</Text>
        </View>
        <View style={[styles.frameGroup, styles.frameLayout]}>
          <View style={[styles.firstNameWrapper, styles.wrapperShadowBox]}>
            <Text style={[styles.password, styles.passwordTypo]}>
              First Name
            </Text>
          </View>
          <Text style={[styles.nopal, styles.nopalTypo]}>Nopal</Text>
          <View style={[styles.lastNameWrapper, styles.wrapperShadowBox]}>
            <Text style={[styles.lastName, styles.passwordTypo]}>
              Last Name
            </Text>
          </View>
          <Text style={[styles.konteng, styles.nopalTypo]}>konteng</Text>
          <Image
            style={[styles.frameChild, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameItem, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameInner, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.ellipseIcon, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameChild1, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameChild2, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameChild3, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
          <Image
            style={[styles.frameChild4, styles.frameChildLayout]}
            resizeMode="cover"
            source={require("../assets/ellipse-1.png")}
          />
        </View>
        <View style={[styles.emailIdWrapper, styles.wrapperShadowBox]}>
          <Text style={[styles.lastName, styles.passwordTypo]}>Email Id</Text>
        </View>
        <Text style={[styles.nopalkonteng88googlecom, styles.nopalTypo]}>
          Nopalkonteng88@google.com
        </Text>
      </View>
      <Image
        style={[styles.iconlylightshow, styles.iconlylightshowPosition]}
        resizeMode="cover"
        source={require("../assets/iconlylightshow.png")}
      />
      <Image
        style={[styles.pembuatanAccount3Inner, styles.iconlylightshowPosition]}
        resizeMode="cover"
        source={require("../assets/line-1.png")}
      />
      <Pressable
        style={styles.iconlytwoTonearrowLeft2}
        onPress={() => navigation.navigate("PembuatanAccount2")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-4.png")}
        />
      </Pressable>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
      <Text style={[styles.text10, styles.nopalTypo]}>9:30</Text>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  numberPosition: {
    left: "0%",
    right: "0%",
    width: "100%",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  textClr: {
    color: Color.black,
    textAlign: "left",
    position: "absolute",
  },
  viewPosition2: {
    top: 93,
    height: 47,
    width: 99,
    position: "absolute",
  },
  viewPosition1: {
    top: 37,
    height: 47,
    width: 99,
    position: "absolute",
  },
  viewPosition: {
    top: -22,
    height: 47,
    width: 99,
    position: "absolute",
  },
  frameLayout: {
    width: 320,
    position: "absolute",
  },
  passwordTypo: {
    height: 13,
    color: Color.darkgray_200,
    textTransform: "uppercase",
    fontSize: FontSize.size_5xs,
    top: 4,
    left: 12,
    fontFamily: FontFamily.poppinsSemibold,
    fontWeight: "600",
    textAlign: "left",
    position: "absolute",
  },
  wrapperShadowBox: {
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 40,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_8xs,
    position: "absolute",
    backgroundColor: Color.white,
  },
  nopalTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  frameChildLayout: {
    height: 8,
    width: 8,
    top: 120,
    position: "absolute",
  },
  iconlylightshowPosition: {
    height: 16,
    top: 297,
    position: "absolute",
  },
  pembuatanAccount3Child: {
    top: -50,
    left: -22,
    width: 375,
    height: 555,
    position: "absolute",
    backgroundColor: Color.white,
  },
  numberKeyboardChild: {
    height: "137.38%",
    top: "-17.29%",
    bottom: "-20.09%",
    left: "0%",
    right: "0%",
    width: "100%",
  },
  rectangleIcon: {
    height: "104.27%",
    width: "102.02%",
    top: "0%",
    right: "-1.01%",
    bottom: "-4.27%",
    left: "-1.01%",
  },
  text: {
    top: "11.07%",
    left: "42.88%",
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_11xl,
    width: "20.24%",
    height: "79.55%",
    color: Color.black,
  },
  view: {
    top: 153,
    height: 47,
    width: 99,
    left: 125,
    position: "absolute",
  },
  text1: {
    top: "6.82%",
    left: "39.88%",
    textAlign: "left",
    fontFamily: FontFamily.robotoRegular,
    fontSize: FontSize.size_11xl,
    width: "20.24%",
    height: "79.55%",
    color: Color.black,
  },
  view1: {
    left: 231,
  },
  view2: {
    left: 125,
    top: 93,
  },
  view3: {
    left: 15,
  },
  view4: {
    left: 231,
  },
  view5: {
    left: 124,
  },
  view6: {
    left: 15,
  },
  view7: {
    left: 231,
  },
  view8: {
    left: 124,
  },
  view9: {
    left: 15,
  },
  fill1Icon: {
    height: "9.59%",
    width: "7.41%",
    top: "75.36%",
    right: "16.12%",
    bottom: "15.05%",
    left: "76.47%",
  },
  numberKeyboard: {
    height: "27.45%",
    top: "73.15%",
    bottom: "-0.6%",
    position: "absolute",
  },
  pembuatanAccount3Item: {
    top: 467,
    left: 28,
    backgroundColor: Color.steelblue,
    height: 61,
    width: 319,
    position: "absolute",
    borderRadius: Border.br_3xs,
  },
  continue1: {
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.white,
    height: 31,
    textAlign: "left",
    width: 99,
  },
  continue: {
    left: 138,
    top: 483,
    position: "absolute",
  },
  welcome: {
    top: 97,
    fontSize: FontSize.size_5xl,
    height: 32,
    fontFamily: FontFamily.poppinsSemibold,
    fontWeight: "600",
    left: 27,
    width: 319,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  pleaseProvideUs: {
    top: 136,
    left: 26,
    fontFamily: FontFamily.poppinsRegular,
    width: 321,
    height: 22,
    fontSize: FontSize.size_base,
    textAlign: "left",
  },
  password: {
    width: 49,
  },
  passwordWrapper: {
    top: 100,
    shadowColor: "#46de99",
    height: 40,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderRadius: Border.br_8xs,
    left: 0,
    width: 320,
    position: "absolute",
    backgroundColor: Color.white,
  },
  firstNameWrapper: {
    width: 157,
    top: 0,
    left: 0,
  },
  nopal: {
    top: 13,
    fontWeight: "500",
    fontSize: FontSize.size_base,
    left: 12,
  },
  lastName: {
    width: 48,
  },
  lastNameWrapper: {
    left: 165,
    width: 155,
    top: 0,
  },
  konteng: {
    left: 176,
    top: 13,
    fontWeight: "500",
    fontSize: FontSize.size_base,
  },
  frameChild: {
    left: 12,
  },
  frameItem: {
    left: 23,
  },
  frameInner: {
    left: 34,
  },
  ellipseIcon: {
    left: 45,
  },
  frameChild1: {
    left: 56,
  },
  frameChild2: {
    left: 67,
  },
  frameChild3: {
    left: 78,
  },
  frameChild4: {
    left: 89,
  },
  frameGroup: {
    height: 128,
    top: 0,
    left: 0,
  },
  emailIdWrapper: {
    top: 50,
    left: 0,
    width: 319,
  },
  nopalkonteng88googlecom: {
    top: 63,
    left: 12,
    fontSize: FontSize.size_base,
  },
  frameParent: {
    top: 181,
    height: 140,
    left: 27,
    width: 320,
  },
  iconlylightshow: {
    left: 323,
    width: 16,
  },
  pembuatanAccount3Inner: {
    left: 326,
    width: 11,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft2: {
    left: 16,
    top: 44,
    width: 35,
    height: 35,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -389.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  text10: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    width: 26,
    height: 19,
  },
  pembuatanAccount3: {
    flex: 1,
    height: 808,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default PembuatanAccount3;
