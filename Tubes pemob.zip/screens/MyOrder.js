import * as React from "react";
import { Text, StyleSheet, Image, Pressable, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { FontSize, Color, FontFamily, Border } from "../GlobalStyles";

const MyOrder = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.myOrder}>
      <Text style={styles.myOrder1}>My Order</Text>
      <Pressable
        style={styles.iconlytwoTonearrowLeft2}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-2.png")}
        />
      </Pressable>
      <Pressable
        style={styles.iconlytwoTonearrowLeft2}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-2.png")}
        />
      </Pressable>
      <View style={styles.groupParent}>
        <View style={styles.rectangleWrapper}>
          <View style={styles.groupShadowBox} />
        </View>
        <Text style={styles.rp225000}>Rp225.000</Text>
        <Text style={[styles.text, styles.textTypo]}>#87234098772</Text>
        <Text style={[styles.may152023, styles.may152023Typo]}>
          May 15, 2023 at 6:00 PM
        </Text>
        <Text style={[styles.items, styles.textPosition]}>2 Items</Text>
        <Text style={[styles.playStation5, styles.may152023Typo]}>
          Play Station 5 and Nintendo Switch
        </Text>
        <Image
          style={[styles.iconlyboldlocation, styles.fiRsRefreshIconLayout]}
          resizeMode="cover"
          source={require("../assets/iconlyboldlocation2.png")}
        />
      </View>
      <View style={[styles.groupContainer, styles.groupLayout]}>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={styles.rectangleWrapper}>
            <View style={styles.groupShadowBox} />
          </View>
          <View style={styles.dollarCurrencySymbol1} />
          <Text style={[styles.rp85000, styles.rp85000Typo]}>Rp.85.000</Text>
          <Text style={[styles.text, styles.textTypo]}>#972430981233</Text>
          <Text style={[styles.may152023, styles.may152023Typo]}>
            May 10, 2023 at 3:00 PM
          </Text>
          <Text style={[styles.items, styles.textPosition]}>1 Items</Text>
          <Text style={[styles.playStation5, styles.may152023Typo]}>
            Nitendo switch x 1
          </Text>
          <Text style={[styles.reOrder, styles.text3Typo]}>Re-Order</Text>
        </View>
        <Image
          style={[styles.fiRsRefreshIcon, styles.fiRsRefreshIconLayout]}
          resizeMode="cover"
          source={require("../assets/firsrefresh.png")}
        />
      </View>
      <View style={[styles.groupParent1, styles.groupLayout]}>
        <View style={[styles.groupView, styles.groupLayout]}>
          <View style={styles.rectangleWrapper}>
            <View style={styles.groupShadowBox} />
          </View>
          <Text style={[styles.rp400000, styles.rp85000Typo]}>Rp400.000</Text>
          <Text style={[styles.text, styles.textTypo]}>#922220981456</Text>
          <Text style={[styles.may152023, styles.may152023Typo]}>
            April 1, 2023 at 8:00 PM
          </Text>
          <Text style={[styles.items, styles.textPosition]}>4 Items</Text>
          <Text style={[styles.playStation5, styles.may152023Typo]}>
            Playstation x 1, Xbox x 1, Peripheral x 2
          </Text>
          <Text style={[styles.reOrder, styles.text3Typo]}>Re-Order</Text>
        </View>
        <Image
          style={[styles.fiRsRefreshIcon, styles.fiRsRefreshIconLayout]}
          resizeMode="cover"
          source={require("../assets/firsrefresh.png")}
        />
      </View>
      <View style={styles.myOrderInnerPosition}>
        <View style={[styles.rectangleView, styles.myOrderInnerPosition]} />
      </View>
      <Text style={[styles.text3, styles.text3Typo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element1.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo: {
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  may152023Typo: {
    fontFamily: FontFamily.poppinsRegular,
    left: 23,
    textAlign: "left",
    position: "absolute",
  },
  textPosition: {
    left: 23,
    textAlign: "left",
    position: "absolute",
  },
  fiRsRefreshIconLayout: {
    height: 16,
    width: 16,
    top: 16,
    position: "absolute",
  },
  groupLayout: {
    width: 320,
    height: 133,
    position: "absolute",
  },
  rp85000Typo: {
    width: 113,
    left: 207,
    height: 25,
    color: Color.steelblue,
    lineHeight: 24,
    fontSize: 20,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text3Typo: {
    fontSize: FontSize.size_xs,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  myOrderInnerPosition: {
    height: 34,
    width: 375,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    position: "absolute",
  },
  myOrder1: {
    top: 81,
    left: 25,
    fontSize: FontSize.size_17xl,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft2: {
    left: 16,
    top: 43,
    width: 35,
    height: 35,
    position: "absolute",
  },
  groupShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowColor: "rgba(0, 0, 0, 0.2)",
    width: 319,
    left: 0,
    top: 0,
    height: 133,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  rectangleWrapper: {
    width: 319,
    left: 0,
    top: 0,
    height: 133,
    position: "absolute",
  },
  rp225000: {
    top: 86,
    left: 211,
    width: 138,
    height: 25,
    lineHeight: 24,
    fontSize: 20,
    color: Color.steelblue,
    textAlign: "left",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  text: {
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    left: 23,
    textAlign: "left",
    position: "absolute",
    top: 17,
  },
  may152023: {
    top: 38,
    fontSize: FontSize.size_sm,
    color: Color.black,
  },
  items: {
    top: 71,
    fontSize: FontSize.size_3xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 23,
  },
  playStation5: {
    top: 90,
    fontSize: FontSize.size_5xs,
    color: Color.darkgray_300,
  },
  iconlyboldlocation: {
    left: 207,
    width: 16,
    top: 16,
  },
  groupParent: {
    top: 158,
    width: 349,
    height: 133,
    left: 28,
    position: "absolute",
  },
  dollarCurrencySymbol1: {
    top: 96,
    left: 236,
    width: 15,
    height: 15,
    position: "absolute",
    overflow: "hidden",
  },
  rp85000: {
    top: 88,
  },
  reOrder: {
    left: 238,
    lineHeight: 14,
    top: 17,
    color: Color.steelblue,
    fontSize: FontSize.size_xs,
  },
  groupView: {
    left: 0,
    top: 0,
    width: 320,
  },
  fiRsRefreshIcon: {
    left: 216,
    width: 16,
    top: 16,
    overflow: "hidden",
  },
  groupContainer: {
    top: 305,
    left: 28,
    width: 320,
  },
  rp400000: {
    top: 89,
  },
  groupParent1: {
    top: 452,
    left: 28,
    width: 320,
  },
  rectangleView: {
    backgroundColor: Color.white,
  },
  text3: {
    top: 15,
    left: 29,
    width: 26,
    height: 19,
    color: Color.black,
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  myOrder: {
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default MyOrder;
