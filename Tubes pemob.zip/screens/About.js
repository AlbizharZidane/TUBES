import * as React from "react";
import { Text, StyleSheet, View, Image, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const About = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.about}>
      <Text style={[styles.about1, styles.text1Typo]}>{`About `}</Text>
      <View style={styles.groupParent}>
        <View style={styles.aplikasiPosition}>
          <Text
            style={[styles.aplikasiYangMenyewakan, styles.aplikasiPosition]}
          >
            Aplikasi yang menyewakan berbagai equipment game untuk jangka waktu
            yang singkat,menyewakan berbagai equipment mulai dari beberapa jam
            hingga beberapa minggu.
          </Text>
        </View>
        <View style={[styles.textWrapper, styles.textLayout]}>
          <Text style={[styles.text, styles.textLayout]}>{` `}</Text>
        </View>
      </View>
      <Pressable
        style={styles.iconlytwoTonearrowLeft4}
        onPress={() => navigation.navigate("Profile")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/iconlytwotonearrow--left-4.png")}
        />
      </Pressable>
      <View style={styles.aboutInnerPosition}>
        <View style={[styles.groupChild, styles.aboutInnerPosition]} />
      </View>
      <Text style={[styles.text1, styles.text1Typo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  text1Typo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  aplikasiPosition: {
    left: 0,
    top: 0,
    height: 242,
    width: 325,
    position: "absolute",
  },
  textLayout: {
    height: 23,
    width: 82,
    left: 0,
    position: "absolute",
  },
  aboutInnerPosition: {
    height: 34,
    width: 375,
    left: "50%",
    marginLeft: -187.5,
    top: 0,
    position: "absolute",
  },
  about1: {
    top: 81,
    left: 25,
    fontSize: FontSize.size_17xl,
    position: "absolute",
  },
  aplikasiYangMenyewakan: {
    fontSize: 21,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  text: {
    fontSize: 14,
    textTransform: "uppercase",
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.steelblue,
    top: 0,
    width: 82,
    textAlign: "left",
  },
  textWrapper: {
    top: 44,
  },
  groupParent: {
    top: 164,
    height: 242,
    width: 325,
    left: 20,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  iconlytwoTonearrowLeft4: {
    top: 46,
    width: 35,
    height: 35,
    left: 20,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.white,
  },
  text1: {
    top: 15,
    left: 29,
    fontSize: FontSize.size_xs,
    width: 26,
    height: 19,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  about: {
    borderRadius: Border.br_3xs,
    flex: 1,
    height: 812,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default About;
