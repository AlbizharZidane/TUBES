import * as React from "react";
import { Image, StyleSheet, View, Text, Pressable } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const ManageAddress = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.manageAddress}>
      <Image
        style={styles.frame81}
        resizeMode="cover"
        source={require("../assets/frame-8-1.png")}
      />
      <View style={styles.background} />
      <Text style={[styles.searchAddress, styles.addressTypo]}>
        Search Address
      </Text>
      <View style={styles.manageAddressChild} />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={[styles.searchLocation, styles.searchLocationTypo]}>
        Search location
      </Text>
      <View style={[styles.rectangleParent, styles.homeLayout]}>
        <View style={styles.childShadowBox} />
        <Image
          style={[styles.fiRrTargetIcon, styles.fiRrTargetIconLayout]}
          resizeMode="cover"
          source={require("../assets/firrtarget.png")}
        />
        <Text style={[styles.currentLocation, styles.savedAddressesTypo]}>
          Current Location
        </Text>
      </View>
      <Text style={[styles.savedAddresses, styles.savedAddressesTypo]}>
        Saved Addresses
      </Text>
      <View style={[styles.home, styles.homeLayout]}>
        <View style={styles.childShadowBox} />
        <Text style={[styles.koarmanglabangalore, styles.searchLocationTypo]}>
          Koarmangla,Bangalore...
        </Text>
        <Text style={[styles.currentLocation, styles.savedAddressesTypo]}>
          Home
        </Text>
        <Image
          style={[styles.iconlylighthome, styles.fiRrTargetIconLayout]}
          resizeMode="cover"
          source={require("../assets/iconlylighthome2.png")}
        />
        <Image
          style={styles.homeItem}
          resizeMode="cover"
          source={require("../assets/group-427.png")}
        />
      </View>
      <View style={[styles.office, styles.homeLayout]}>
        <View style={styles.childShadowBox} />
        <Text style={[styles.koarmanglabangalore, styles.searchLocationTypo]}>
          Koarmangla,Bangalore...
        </Text>
        <Text style={[styles.currentLocation, styles.savedAddressesTypo]}>
          Office
        </Text>
        <Image
          style={[styles.iconlylightwork, styles.fiRrTargetIconLayout]}
          resizeMode="cover"
          source={require("../assets/iconlylightwork.png")}
        />
        <Image
          style={styles.homeItem}
          resizeMode="cover"
          source={require("../assets/group-427.png")}
        />
      </View>
      <View style={[styles.other, styles.homeLayout]}>
        <View style={styles.childShadowBox} />
        <Text style={[styles.koarmanglabangalore, styles.searchLocationTypo]}>
          Koarmangla,Bangalore...
        </Text>
        <Text style={[styles.currentLocation, styles.savedAddressesTypo]}>
          Other
        </Text>
        <Image
          style={[styles.iconlylightwork, styles.fiRrTargetIconLayout]}
          resizeMode="cover"
          source={require("../assets/iconlylightoutlinelocation.png")}
        />
        <Image
          style={styles.homeItem}
          resizeMode="cover"
          source={require("../assets/group-427.png")}
        />
      </View>
      <Pressable
        style={styles.fiBrCross}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Image
          style={styles.icon}
          resizeMode="cover"
          source={require("../assets/fibrcross.png")}
        />
      </Pressable>
      <View style={[styles.addNewAddressParent, styles.addLayout]}>
        <Text style={[styles.addNewAddress, styles.addLayout]}>
          Add New Address
        </Text>
        <Image
          style={styles.fiBrPlusIcon}
          resizeMode="cover"
          source={require("../assets/fibrplus2.png")}
        />
      </View>
      <View style={styles.groupItemPosition}>
        <View style={[styles.groupItem, styles.groupItemPosition]} />
      </View>
      <Text style={[styles.text, styles.addressTypo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  addressTypo: {
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  searchLocationTypo: {
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    position: "absolute",
  },
  homeLayout: {
    height: 54,
    width: 317,
    left: 29,
    position: "absolute",
  },
  fiRrTargetIconLayout: {
    height: 24,
    width: 24,
    left: 14,
    position: "absolute",
  },
  savedAddressesTypo: {
    fontSize: FontSize.size_base,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    position: "absolute",
  },
  addLayout: {
    height: 26,
    position: "absolute",
  },
  groupItemPosition: {
    height: 34,
    left: "50%",
    marginLeft: -187.5,
    width: 375,
    top: 0,
    position: "absolute",
  },
  frame81: {
    width: 375,
    left: 0,
    top: 0,
    position: "absolute",
    height: 812,
  },
  background: {
    top: 104,
    shadowColor: "rgba(85, 85, 85, 0.25)",
    shadowRadius: 11,
    elevation: 11,
    height: 708,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    width: 375,
    left: 0,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  searchAddress: {
    top: 153,
    fontSize: FontSize.size_xl,
    lineHeight: 24,
    left: 29,
    position: "absolute",
  },
  manageAddressChild: {
    top: 189,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    elevation: 4,
    shadowRadius: 4,
    left: 29,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 202,
    left: 44,
    width: 12,
    height: 12,
    position: "absolute",
    overflow: "hidden",
  },
  searchLocation: {
    top: 199,
    left: 67,
    fontSize: FontSize.size_xs,
  },
  childShadowBox: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    height: 54,
    width: 317,
    elevation: 4,
    shadowRadius: 4,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 0,
    top: 0,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiRrTargetIcon: {
    top: 14,
    height: 24,
    width: 24,
    left: 14,
    overflow: "hidden",
  },
  currentLocation: {
    top: 8,
    left: 49,
  },
  rectangleParent: {
    top: 245,
  },
  savedAddresses: {
    top: 309,
    left: 29,
  },
  koarmanglabangalore: {
    top: 27,
    fontSize: FontSize.size_3xs,
    left: 49,
  },
  iconlylighthome: {
    top: 14,
    height: 24,
    width: 24,
    left: 14,
  },
  homeItem: {
    top: 19,
    left: 291,
    width: 3,
    height: 15,
    position: "absolute",
  },
  home: {
    top: 344,
  },
  iconlylightwork: {
    top: 13,
  },
  office: {
    top: 410,
  },
  other: {
    top: 476,
  },
  icon: {
    height: "100%",
    overflow: "hidden",
    width: "100%",
  },
  fiBrCross: {
    left: 331,
    top: 126,
    width: 16,
    height: 16,
    position: "absolute",
  },
  addNewAddress: {
    left: 27,
    fontSize: 20,
    width: 173,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    top: 0,
    height: 26,
  },
  fiBrPlusIcon: {
    top: 3,
    width: 19,
    height: 20,
    left: 0,
    position: "absolute",
    overflow: "hidden",
  },
  addNewAddressParent: {
    top: 744,
    left: 83,
    width: 200,
  },
  groupItem: {
    backgroundColor: Color.white,
    left: "50%",
    marginLeft: -187.5,
  },
  text: {
    top: 15,
    width: 26,
    height: 19,
    fontSize: FontSize.size_xs,
    left: 29,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -386.92,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  manageAddress: {
    flex: 1,
    overflow: "hidden",
    height: 812,
    borderRadius: Border.br_3xs,
    width: "100%",
    backgroundColor: Color.white,
  },
});

export default ManageAddress;
