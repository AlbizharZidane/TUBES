import * as React from "react";
import { StyleSheet, View, Pressable, Image, Text } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const HomeNinetendo = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.homeNinetendo}>
      <Pressable
        style={styles.homeNinetendoChild}
        onPress={() => navigation.navigate("Search")}
      />
      <Image
        style={styles.fiBrSearchIcon}
        resizeMode="cover"
        source={require("../assets/fibrsearch2.png")}
      />
      <Text style={[styles.search, styles.editionTypo1]}>{`search `}</Text>
      <Image
        style={styles.maskGroupIconPosition}
        resizeMode="cover"
        source={require("../assets/mask-group.png")}
      />
      <LinearGradient
        style={[styles.homeNinetendoItem, styles.maskGroupIconPosition]}
        locations={[0, 0.25, 1]}
        colors={["#000", "#000", "rgba(0, 0, 0, 0)"]}
        useAngle={true}
        angle={90}
      />
      <Text style={[styles.rp150000, styles.ps5Clr]}>Rp150.000</Text>
      <Text style={[styles.flashSale, styles.editionTypo]}>Flash sale</Text>
      <Text style={styles.exploreCategories}>Explore Categories</Text>
      <Text style={styles.exploreCategories}>Explore Categories</Text>
      <Text style={[styles.ps5, styles.editionTypo]}>PS 5 + GOW Ragnarok</Text>
      <Text style={[styles.only, styles.editionTypo]}>only</Text>
      <View style={[styles.homeNinetendoInner, styles.homeChildShadowBox]} />
      <View style={[styles.rectangleView, styles.homeChildShadowBox]} />
      <View style={[styles.homeNinetendoChild1, styles.homeChildShadowBox]} />
      <View style={[styles.homeNinetendoChild2, styles.homeChildShadowBox]} />
      <Pressable
        style={styles.pngTransparentBlackJoystick}
        onPress={() => navigation.navigate("HomePeripheral")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentblackjoystickplaystation3gamecontrollerscontrollerelectronicsvideogameblack-3.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.playstationLogowine1, styles.playstationLogowine1Layout]}
        onPress={() => navigation.navigate("HomePlaystation")}
      >
        <Image
          style={[styles.icon1, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/playstationlogowine-1.png")}
        />
      </Pressable>
      <Text style={[styles.playstation, styles.vodkaTypo]}>Playstation</Text>
      <Text style={[styles.nintendo, styles.xboxTypo]}>Nintendo</Text>
      <Text style={[styles.peripheral, styles.xboxTypo]}>Peripheral</Text>
      <Pressable
        style={styles.showAll}
        onPress={() => navigation.navigate("HomeDefault")}
      >
        <Text style={[styles.showAll1, styles.editionTypo]}>Show all</Text>
      </Pressable>
      <Text style={[styles.vodka, styles.vodkaTypo]}>Vodka</Text>
      <Image
        style={styles.frameIcon}
        resizeMode="cover"
        source={require("../assets/frame1.png")}
      />
      <Text style={[styles.xbox, styles.xboxTypo]}>Xbox</Text>
      <View style={styles.downNavBarParent}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeChild, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={styles.rectangleParent}>
        <View style={[styles.groupChild, styles.groupShadowBox]} />
        <Text style={styles.rp80000}>Rp80.000</Text>
        <View style={[styles.groupItem, styles.groupItemPosition]} />
        <View style={[styles.groupInner, styles.groupShadowBox]} />
        <View style={[styles.nintendoSwitchParent, styles.nintendoLayout]}>
          <Text style={[styles.nintendoSwitch, styles.nintendoLayout]}>
            Nintendo Switch
          </Text>
          <Text style={[styles.rp85000, styles.rp85000Typo]}>Rp85.000</Text>
        </View>
        <View style={[styles.nintendoSwitchGroup, styles.nintendoLayout]}>
          <Text
            style={[styles.nintendoSwitch, styles.nintendoLayout]}
          >{`Nintendo Switch `}</Text>
          <Text style={[styles.rp850001, styles.rp85000Typo]}>Rp85.000</Text>
          <Text style={[styles.leftInStock, styles.vodkaTypo]}>
            10 left in Stock
          </Text>
        </View>
        <View style={[styles.nintendoSwitchWrapper, styles.nintendoLayout]}>
          <Text style={[styles.nintendoSwitch, styles.nintendoLayout]}>
            Nintendo Switch
          </Text>
        </View>
      </View>
      <Text style={styles.nintendo1}>{`Nintendo `}</Text>
      <Text style={[styles.pokemonEdition, styles.editionTypo]}>
        Pokemon Edition
      </Text>
      <Text style={[styles.superMarioEdition, styles.editionTypo]}>
        Super mario Edition
      </Text>
      <Pressable
        style={[styles.download33, styles.download33Position]}
        onPress={() => navigation.navigate("QuickOrderNintendi")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/download-3-31.png")}
        />
      </Pressable>
      <Image
        style={[
          styles.pngTransparentNintendoSwitcIcon,
          styles.playstationLogowine1Layout,
        ]}
        resizeMode="cover"
        source={require("../assets/pngtransparentnintendoswitchwiiulumologonintendoangletextnintendo-3.png")}
      />
      <Pressable
        style={styles.pngTransparentXbox360Black}
        onPress={() => navigation.navigate("HomeXbox")}
      >
        <Image
          style={styles.iconLayout}
          resizeMode="cover"
          source={require("../assets/pngtransparentxbox360blackxboxangleelectronicslogo-3.png")}
        />
      </Pressable>
      <Image
        style={[
          styles.dbnc6ssB61ddaad372c4f569bbIcon,
          styles.download33Position,
        ]}
        resizeMode="cover"
        source={require("../assets/dbnc6ssb61ddaad372c4f569bbc631d3e26e5b7-1.png")}
      />
      <View style={styles.groupPosition}>
        <View style={[styles.groupChild1, styles.groupPosition]} />
      </View>
      <View style={[styles.downNavBarGroup, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeItem, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <View style={[styles.cart, styles.homePosition1]}>
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </View>
        <View style={[styles.profile, styles.profilePosition]}>
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </View>
      </View>
      <View style={[styles.downNavBarContainer, styles.downPosition]}>
        <View style={styles.downShadowBox} />
        <View style={[styles.home, styles.homePosition1]}>
          <Image
            style={[styles.homeInner, styles.homePosition]}
            resizeMode="cover"
            source={require("../assets/vector-51.png")}
          />
          <Image
            style={[styles.iconlylighthome, styles.homePosition1]}
            resizeMode="cover"
            source={require("../assets/iconlylighthome1.png")}
          />
          <Text style={[styles.home1, styles.profilePosition]}>Home</Text>
        </View>
        <Pressable
          style={[styles.cart, styles.homePosition1]}
          onPress={() => navigation.navigate("Pembelian")}
        >
          <Image
            style={[styles.fiRrShoppingCartIcon, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/firrshoppingcart.png")}
          />
          <Text style={[styles.cart1, styles.cartPosition]}>Cart</Text>
        </Pressable>
        <Pressable
          style={[styles.profile, styles.profilePosition]}
          onPress={() => navigation.navigate("Profile")}
        >
          <Image
            style={[styles.iconlycurvedprofile, styles.cartPosition]}
            resizeMode="cover"
            source={require("../assets/iconlycurvedprofile1.png")}
          />
          <Text style={[styles.profile1, styles.profilePosition]}>Profile</Text>
        </Pressable>
      </View>
      <Text style={[styles.text, styles.onlyTypo]}>9:30</Text>
      <Image
        style={styles.topbarElementIcon}
        resizeMode="cover"
        source={require("../assets/topbar-element.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  editionTypo1: {
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
    position: "absolute",
  },
  maskGroupIconPosition: {
    height: 120,
    top: 113,
    width: 317,
    left: 29,
    position: "absolute",
  },
  ps5Clr: {
    color: Color.white,
    position: "absolute",
  },
  editionTypo: {
    fontSize: FontSize.size_3xs,
    textAlign: "left",
  },
  homeChildShadowBox: {
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  playstationLogowine1Layout: {
    height: 61,
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  vodkaTypo: {
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  xboxTypo: {
    top: 362,
    fontSize: FontSize.size_5xs,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  homePosition1: {
    left: "50%",
    position: "absolute",
  },
  homePosition: {
    height: 16,
    bottom: 51,
    left: "50%",
    width: 72,
    position: "absolute",
  },
  profilePosition: {
    width: 31,
    left: "50%",
    position: "absolute",
  },
  cartPosition: {
    marginLeft: -11.5,
    left: "50%",
    position: "absolute",
  },
  groupShadowBox: {
    height: 99,
    width: 363,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  groupItemPosition: {
    top: 0,
    left: 0,
  },
  nintendoLayout: {
    width: 131,
    position: "absolute",
  },
  rp85000Typo: {
    width: 108,
    left: 1,
    fontSize: FontSize.size_xl,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  download33Position: {
    left: 13,
    position: "absolute",
  },
  groupPosition: {
    height: 34,
    top: 0,
    marginLeft: -187.5,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  downPosition: {
    bottom: 5,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  onlyTypo: {
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  homeNinetendoChild: {
    top: 55,
    shadowColor: "rgba(0, 0, 0, 0.2)",
    height: 38,
    width: 317,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    left: 29,
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  fiBrSearchIcon: {
    top: 68,
    width: 12,
    height: 12,
    left: 44,
    position: "absolute",
    overflow: "hidden",
  },
  search: {
    top: 65,
    left: 67,
    textAlign: "left",
    color: Color.darkgray_300,
    fontSize: FontSize.size_xs,
  },
  homeNinetendoItem: {
    backgroundColor: "transparent",
    borderRadius: Border.br_3xs,
    height: 120,
  },
  rp150000: {
    top: 179,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
    color: Color.white,
    textAlign: "left",
  },
  flashSale: {
    top: 124,
    left: 43,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  exploreCategories: {
    top: 247,
    left: 28,
    color: Color.black,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  ps5: {
    top: 212,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemibold,
    color: Color.white,
    position: "absolute",
    left: 42,
  },
  only: {
    top: 168,
    color: Color.white,
    position: "absolute",
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 42,
  },
  homeNinetendoInner: {
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
    left: 29,
  },
  rectangleView: {
    left: 111,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homeNinetendoChild1: {
    left: 193,
    width: 72,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  homeNinetendoChild2: {
    left: 276,
    width: 71,
    height: 95,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 286,
  },
  pngTransparentBlackJoystick: {
    left: 282,
    top: 303,
    height: 44,
    width: 65,
    position: "absolute",
  },
  icon1: {
    overflow: "hidden",
  },
  playstationLogowine1: {
    left: 16,
    top: 293,
    width: 101,
  },
  playstation: {
    top: 361,
    color: Color.black,
    left: 44,
  },
  nintendo: {
    left: 127,
  },
  peripheral: {
    left: 293,
  },
  showAll1: {
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
  },
  showAll: {
    left: 305,
    top: 256,
    position: "absolute",
  },
  vodka: {
    top: 395,
    left: 381,
    color: Color.black,
  },
  frameIcon: {
    top: 328,
    left: 382,
    height: 65,
    width: 23,
    position: "absolute",
    overflow: "hidden",
  },
  xbox: {
    left: 219,
  },
  downShadowBox: {
    elevation: 3,
    shadowRadius: 3,
    shadowColor: "rgba(85, 85, 85, 0.2)",
    bottom: 0,
    marginLeft: -187.5,
    height: 75,
    width: 375,
    left: "50%",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  homeChild: {
    marginLeft: -35.87,
  },
  iconlylighthome: {
    marginLeft: -14.13,
    bottom: 17,
    width: 27,
    height: 27,
  },
  home1: {
    marginLeft: -16.13,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.steelblue,
  },
  home: {
    marginLeft: -179.23,
    height: 67,
    bottom: 8,
    width: 72,
  },
  fiRrShoppingCartIcon: {
    bottom: 18,
    height: 23,
    width: 23,
    overflow: "hidden",
  },
  cart1: {
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    width: 23,
    color: Color.darkgray_300,
  },
  cart: {
    marginLeft: -20.5,
    bottom: 9,
    height: 41,
    width: 23,
  },
  iconlycurvedprofile: {
    bottom: 16,
    width: 24,
    height: 24,
  },
  profile1: {
    marginLeft: -15.5,
    textAlign: "center",
    height: 16,
    bottom: 0,
    fontSize: FontSize.size_5xs,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.darkgray_300,
  },
  profile: {
    marginLeft: 128.5,
    height: 40,
    bottom: 8,
  },
  downNavBarParent: {
    marginLeft: -179.5,
    bottom: 6,
    height: 75,
    width: 375,
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    top: 226,
    left: 0,
  },
  rp80000: {
    top: 284,
    width: 110,
    fontSize: FontSize.size_xl,
    left: 98,
    color: Color.steelblue,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  groupItem: {
    height: 99,
    width: 363,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    position: "absolute",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
  groupInner: {
    left: 0,
    top: 113,
    height: 99,
  },
  nintendoSwitch: {
    fontSize: FontSize.size_sm,
    top: 0,
    left: 0,
    color: Color.black,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
  },
  rp85000: {
    top: 40,
  },
  nintendoSwitchParent: {
    left: 92,
    height: 70,
    top: 15,
  },
  rp850001: {
    top: 37,
  },
  leftInStock: {
    top: 59,
    color: Color.red,
    display: "none",
    left: 0,
    width: 65,
  },
  nintendoSwitchGroup: {
    top: 130,
    left: 97,
    height: 67,
  },
  nintendoSwitchWrapper: {
    top: 241,
    height: 21,
    left: 98,
    width: 131,
  },
  rectangleParent: {
    top: 433,
    height: 325,
    width: 363,
    left: 8,
    position: "absolute",
  },
  nintendo1: {
    top: 391,
    left: 8,
    color: Color.black,
    fontSize: FontSize.size_base,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    textAlign: "left",
    position: "absolute",
  },
  pokemonEdition: {
    top: 580,
    left: 107,
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  superMarioEdition: {
    left: 102,
    top: 465,
    color: Color.darkgray_300,
    fontFamily: FontFamily.poppinsRegular,
    position: "absolute",
  },
  download33: {
    top: 685,
    width: 85,
    height: 47,
  },
  pngTransparentNintendoSwitcIcon: {
    top: 298,
    left: 115,
    width: 61,
  },
  pngTransparentXbox360Black: {
    left: 204,
    top: 302,
    width: 51,
    height: 51,
    position: "absolute",
  },
  dbnc6ssB61ddaad372c4f569bbIcon: {
    width: 69,
    height: 35,
    top: 465,
  },
  groupChild1: {
    backgroundColor: Color.white,
    height: 34,
  },
  homeItem: {
    marginLeft: -26.13,
  },
  downNavBarGroup: {
    marginLeft: -191.5,
  },
  homeInner: {
    marginLeft: -30.13,
  },
  downNavBarContainer: {
    marginLeft: -187.5,
    bottom: 5,
  },
  text: {
    width: 26,
    height: 19,
    top: 15,
    color: Color.black,
    textAlign: "left",
    fontSize: FontSize.size_xs,
    left: 29,
    position: "absolute",
  },
  topbarElementIcon: {
    marginTop: -421.42,
    top: "50%",
    right: 18,
    width: 60,
    height: 10,
    position: "absolute",
  },
  homeNinetendo: {
    flex: 1,
    height: 877,
    overflow: "hidden",
    width: "100%",
    backgroundColor: Color.white,
    borderRadius: Border.br_3xs,
  },
});

export default HomeNinetendo;
