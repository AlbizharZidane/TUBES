/* fonts */
export const FontFamily = {
  montserratMedium: "Montserrat_medium",
  montserratSemibold: "Montserrat_semibold",
  montserratLight: "Montserrat_light",
  poppinsMedium: "Poppins_medium",
  poppinsRegular: "Poppins_regular",
  poppinsBold: "Poppins_bold",
  poppinsSemibold: "Poppins_semibold",
  robotoRegular: "Roboto_regular",
};
/* font sizes */
export const FontSize = {
  size_base: 16,
  size_sm: 14,
  size_xs: 12,
  size_5xs: 8,
  size_11xl: 30,
  size_xl: 20,
  size_2xl_2: 21,
  size_sm_6: 14,
  size_17xl: 36,
  size_3xs: 10,
  size_5xl: 24,
  size_4xl: 23,
  size_xl_4: 20,
  size_2xs_7: 11,
  size_sm_4: 13,
};
/* Colors */
export const Color = {
  steelblue: "#2287b9",
  white: "#fff",
  black: "#000",
  darkgray_100: "#b3b3b3",
  darkgray_200: "#a9a7a7",
  darkgray_300: "#979797",
  mediumseagreen_100: "#46de99",
  mediumseagreen_200: "rgba(70, 222, 153, 0.2)",
  whitesmoke_100: "#f6f6f6",
  whitesmoke_200: "#f3f3f3",
  red: "#ff0000",
};
/* border radiuses */
export const Border = {
  br_3xs: 10,
  br_9xs: 4,
  br_8xs: 5,
  br_10xs: 3,
  br_sm_4: 13,
};
