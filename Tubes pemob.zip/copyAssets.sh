#!/bin/bash

# Destination folder in the iOS bundle where the assets will be copied
mkdir -p "${TARGET_BUILD_DIR}/${UNLOCALIZED_RESOURCES_FOLDER_PATH}"

ASSETS_FOLDER="${TARGET_BUILD_DIR}/${UNLOCALIZED_RESOURCES_FOLDER_PATH}/"

# Source folder containing the assets
ASSETS_SOURCE_FOLDER="${SRCROOT}/../assets"

# Supported file extensions
SUPPORTED_EXTENSIONS=("otf" "ttf" "mp3" "wav" "3gpp" "mp4" "m4a" "ogg" "aac" "aif" "aiff" "snd")


# Function to copy files with specific extensions recursively
copyFilesWithExtensionsRecursive() {
  local sourceFolder=$1
  local destinationFolder=$2
  shift 2
  local extensions=("$@")

  find "$sourceFolder" -type f -iname "*.*" | while read -r file; do
    filename=$(basename "$file")
    extension="${filename##*.}"
    
    if [[ " ${extensions[@]} " =~ " ${extension} " ]]; then
      cp "$file" "$ASSETS_FOLDER"
    fi
  done
}

# Copy all assets recursively
copyFilesWithExtensionsRecursive "$ASSETS_SOURCE_FOLDER" "$ASSETS_FOLDER" "${SUPPORTED_EXTENSIONS[@]}"
