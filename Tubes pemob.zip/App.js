const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";

import TampilanAwal from "./screens/TampilanAwal";
import Search from "./screens/Search";
import PlaceOrderStep1 from "./screens/PlaceOrderStep1";
import PersonalInfo from "./screens/PersonalInfo";
import About from "./screens/About";
import Profile from "./screens/Profile";
import Pembayaran3 from "./screens/Pembayaran3";
import Pembayaran2 from "./screens/Pembayaran2";
import QuickOrderNintendi from "./screens/QuickOrderNintendi";
import QuickOrderXbox from "./screens/QuickOrderXbox";
import HomePeripheral from "./screens/HomePeripheral";
import HomeXbox from "./screens/HomeXbox";
import HomeNinetendo from "./screens/HomeNinetendo";
import HomePlaystation from "./screens/HomePlaystation";
import Pembelian3 from "./screens/Pembelian3";
import Pembelian2 from "./screens/Pembelian2";
import ProductNintendo from "./screens/ProductNintendo";
import ProductXbox from "./screens/ProductXbox";
import WelcomeLogin from "./screens/WelcomeLogin";
import Pembayaran from "./screens/Pembayaran";
import Pembelian from "./screens/Pembelian";
import ProductPlaystation from "./screens/ProductPlaystation";
import ManageAddress from "./screens/ManageAddress";
import QuickOrderPlaystation from "./screens/QuickOrderPlaystation";
import HomeDefault from "./screens/HomeDefault";
import PembuatanAccount3 from "./screens/PembuatanAccount3";
import PembuatanAccount2 from "./screens/PembuatanAccount2";
import PembuatanAccount1 from "./screens/PembuatanAccount1";
import MyOrder from "./screens/MyOrder";
import RiderChat from "./screens/RiderChat";
import SupportChart from "./screens/SupportChart";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator
            initialRouteName="TampilanAwal"
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen
              name="TampilanAwal"
              component={TampilanAwal}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Search"
              component={Search}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PlaceOrderStep1"
              component={PlaceOrderStep1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PersonalInfo"
              component={PersonalInfo}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="About"
              component={About}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Profile"
              component={Profile}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembayaran3"
              component={Pembayaran3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembayaran2"
              component={Pembayaran2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="QuickOrderNintendi"
              component={QuickOrderNintendi}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="QuickOrderXbox"
              component={QuickOrderXbox}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePeripheral"
              component={HomePeripheral}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomeXbox"
              component={HomeXbox}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomeNinetendo"
              component={HomeNinetendo}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomePlaystation"
              component={HomePlaystation}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembelian3"
              component={Pembelian3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembelian2"
              component={Pembelian2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProductNintendo"
              component={ProductNintendo}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProductXbox"
              component={ProductXbox}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="WelcomeLogin"
              component={WelcomeLogin}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembayaran"
              component={Pembayaran}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="Pembelian"
              component={Pembelian}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ProductPlaystation"
              component={ProductPlaystation}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="ManageAddress"
              component={ManageAddress}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="QuickOrderPlaystation"
              component={QuickOrderPlaystation}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="HomeDefault"
              component={HomeDefault}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PembuatanAccount3"
              component={PembuatanAccount3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PembuatanAccount2"
              component={PembuatanAccount2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="PembuatanAccount1"
              component={PembuatanAccount1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="MyOrder"
              component={MyOrder}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="RiderChat"
              component={RiderChat}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="SupportChart"
              component={SupportChart}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
